library(testthat)
library(spatioTemporalData)

test_package("spatioTemporalData")