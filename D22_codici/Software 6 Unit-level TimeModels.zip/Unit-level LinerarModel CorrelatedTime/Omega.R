###############################################################################
###############################################################################
###
###                             Matriz Omegad                                  
###                            Proyecto SAMPLE                                 
###                           26 Marzo de 2010                                 
###

### AUTOR: Laureano Santamaria Arana

### Editado por:
### con fecha:

#Matriz Omegad y su derivada  
    
Calcula_Omegad <- function(Elem, rho) {
             
    Omegad<-matrix(0,nrow=Elem,ncol=Elem)
    Omegad[lower.tri(Omegad)]<-rho^sequence((Elem-1):1)
    Omegad<-Omegad+t(Omegad)
    diag(Omegad)<-1
    Omegad <- (1/(1-rho^2))*Omegad
    
    return(as.matrix(Omegad))
    
}
              
Deriva_Omegad <- function(Elem, rho, Omegad) {
               
    OmegadPrima<-matrix(0,nrow=Elem,ncol=Elem)
    OmegadPrima[lower.tri(OmegadPrima)] <- sequence((Elem-1):1)*rho^(sequence((Elem-1):1)-1)
    OmegadPrima <- OmegadPrima+t(OmegadPrima)
    OmegadPrima <- (1/(1-rho^2))*OmegadPrima
    OmegadPrima <- OmegadPrima + (2*rho/(1-rho^2))*Omegad
          
    return(as.matrix(OmegadPrima))
}

Inversa_Omegad <- function(Elem, rho) {
               
    Imd <- diag(Elem)
    E <- diag(Elem)
    E[1,1] <- 0
    E[Elem,Elem] <- 0
    F <- diag(Elem)
    for(i in 1:Elem) {
        F[i,i] <- 0
        if (i>1) {
            F[i,i-1] <- 1
        }
        if (i<Elem) {
            F[i,i+1] <- 1            
        }
    }
    OmegadInversa <- matrix(0,nrow=Elem,ncol=Elem)
    OmegadInversa <- Imd + (rho*rho*E) - (rho*F)
          
    return(as.matrix(OmegadInversa))
}
