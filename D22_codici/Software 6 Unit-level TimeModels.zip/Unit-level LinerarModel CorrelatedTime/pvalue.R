###############################################################################
###
###              Area level model with independent time effects 
###                       and with time correlated effects
###                              SAMPLE project
###
### Author: Agust�n Perez Mart�n
### File name: pvalue.R
### Updated: November 25th, 2009
###
###############################################################################

pvalue <- function(beta0, fit) {

    z <- abs(beta0)/sqrt(as.vector(diag(fit[[3]])))
    pval <- 2*pnorm(z, lower.tail=F)

    return( pval )
}
