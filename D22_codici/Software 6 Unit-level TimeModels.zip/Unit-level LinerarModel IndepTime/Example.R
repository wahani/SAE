#setwd("C:/IndividualtimemodelIndep/")
sink("Outputs.txt")
####################################################################
###
###                         Individual-level time models
###                              SAMPLE project
###
### Author: Laureano Santamaria Arana
### File name: Example.R
### Updated: June 25th, 2010
###
#####################################################################

### Establishing the folder where data and routine files are located.
### Call functions

source("REML.R")
source("Estimacion BETA.R")
source("Estimacion MSE.R")
source("Varios.R")

### Reading data
data <- read.table(file = "dataExample.txt", header = T, dec=",")

xdt <- as.matrix(data[,4:(ncol(data)-1)])
ydt <- data[,ncol(data)]
n <- nrow(data)
D <- length(unique(data[,1]))
md <- rep(3,D)
ndi <- c(5,5,5,5,5,5)
NDI <- c(148507,146226,149710,142580,148212,148096)

mdcum <- cumsum(md)
wdt <- rep(1,n)
W <- diag(wdt)
X <- as.matrix(xdt)
Y <- as.matrix(ydt)

Sem <- Calcular.Semilla(X, Y, D, md, ndi)

sigma0 <- as.numeric(Sem[[1]])
sigma1 <- as.numeric(Sem[[2]])
sigma2 <- as.numeric(Sem[[3]])

fit <- REML.area (X, Y, W, D, md, ndi, sigma0, sigma1,
       sigma2, MAXITER = 500)

for(i in 1:3) {
    if (fit[[i]]<0)
        fit[[i]] <- 0.001
}
sigma0.gorro <- fit[[1]]
sigma1.gorro <- fit[[2]]
sigma2.gorro <- fit[[3]]
FisherInv <- fit[[4]]
Iter <- fit[[5]]
Q <- fit[[6]]

B <- BETA.U.area(X, Y, W, D, md, ndi, sigma0.gorro,
    sigma1.gorro, sigma2.gorro)

beta.gorro <- B

fit0 <- list()
fit0[[1]] <- sigma0.gorro
fit0[[2]] <- FisherInv
fit0[[3]] <- Q

Int0 <- Interval.Indep (fit0, 0.90)
pvalue0 <- pvalue(beta.gorro, fit0)

### writing data
    cat("Number of Iter.\t",Iter,"\n")
    cat("\nbeta.gorro\n")
        beta.gorro
    v<-length(beta.gorro)
    for(d in 1:v) { 
        cat("beta.gorro\t", beta.gorro[d],"\tInterval: (",beta.gorro[d]-Int0[[4]][d], beta.gorro[d]+Int0[[4]][d],")\n")
    } 
    cat("\nSigma0.gorro\t",sigma0.gorro,"\tInterval: (",sigma0.gorro-Int0[[1]], sigma0.gorro+Int0[[1]],")\n")
    cat("Sigma1.gorro\t",sigma1.gorro,"\tInterval: (",sigma1.gorro-Int0[[2]], sigma1.gorro+Int0[[2]],")\n")
    cat("Sigma2.gorro\t",sigma2.gorro,"\tInterval: (",sigma2.gorro-Int0[[3]], sigma1.gorro+Int0[[3]],")\n")
    cat("\nPvalue\n")
        pvalue0
    cat("\nPvalue>0.1\n")
        pvalue0>0.1
### End writing datas


#### Calculate and read the population and samples means 
Mxm <- Calcular.Media(X, D,  md, ndi)
Mxp <- read.table(file = "Medias.txt", header = F, dec="," )

### EBLUP of the population parameter for last time instant

Mxp <- as.matrix(Mxp)
Beta <- matrix(beta.gorro,nrow=ncol(X),ncol=1)

mudt.gorro <- Calcular.Yeblup.Indep (X, Y, W, D, md, ndi,
        Beta, sigma0.gorro, sigma1.gorro, sigma2.gorro, Mxp)
sqrt.mse <- sqrt(mse.area(X, Y, W, D, md, ndi, Mxm, NDI,
        Mxp, sigma0.gorro, sigma1.gorro, sigma2.gorro, FisherInv))

Ybarra <- Calcular.Media.Y(Y, D,  md, ndi)

residuals.gorro <- Ybarra-mudt.gorro

### Create .txt files in the folder that contains for the resulting output for last time instant
write.table(data.frame(Direct=Ybarra, EBLUP=mudt.gorro,
        Residuals=residuals.gorro, Sqrt.mse=sqrt.mse),
        file="EBLUP_Example.txt",row.names=FALSE, sep="\t")


sink()
