###
###                    C�lculo de REML para modelo de area                     
###                              Proyecto SAMPLE                               
###                              Proyecto SAMPLE                               
###                                5 deMayo 2009                               
###

### AUTOR: Laureano Santamaria Arana

### Editado por:
### con fecha:
### cambios realizados:         

### Comentarios: 



REML.area <- function(X, Y, W, D, md, ndi, sigma0, sigma1, sigma2, MAXITER = 500) { 
    
    n <- nrow(X)
    p <- ncol(X)

    Sd.inv<-matrix(0, nrow=n, ncol=n)
    
    mdcum <- cumsum(md)
    ndcum <- cumsum(ndi)
    

    for(ITER in 1:MAXITER){
        
        F1 <- sigma1/sigma0  
        F2 <- sigma2/sigma0

        mR <- 0
        mF <- 0
        mJ <- 0
        for(d in 1:D) {      
            if (d==1) {
                Inicio <-1
                Pr <-1
            }
            if (d!=1) {
                Pr <- (ndcum[mdcum[d-1]]+1)
                Inicio <-mdcum[d-1]+1
            }
            Fin  <- ndcum[mdcum[d]]
            Nd <- Fin-Pr+1
 
            Wd <- W[Pr:Fin,Pr:Fin]
            yd <- Y[Pr:Fin]
            Xd <- X[Pr:Fin,]
                   
            D1Nd <- matrix(0,Nd,md[d])
            i <- 1
            for(k in 1:md[d]) {
                for(j in 1:ndi[Inicio+k-1]) {
                    D1Nd[i,k]<-1 
                    i<- i+1
                }
            } 
            Imd<-diag(md[d])
              
            sld.inv <- solve(Imd+F2*t(D1Nd)%*%Wd%*%D1Nd)
            Ld.inv <- Wd-F2*Wd%*%D1Nd%*%sld.inv%*%t(D1Nd)%*%Wd
       
            UnoNd <-as.matrix(rep(1,Nd))

            T1 <- F1*Ld.inv%*%UnoNd%*%t(UnoNd)%*%Ld.inv
            T2 <- 1+(F1*t(UnoNd)%*%Ld.inv%*%UnoNd)
        
            Sigmad.inv <- Ld.inv - (T1/T2[1,1])  
            Sd.inv[Pr:Fin,Pr:Fin] <- Sigmad.inv
        
            mR <- mR + t(Xd)%*%Sigmad.inv%*%Xd              
            mF <- mF + t(Xd)%*%Sigmad.inv%*%UnoNd%*%t(UnoNd)%*%Sigmad.inv%*%Xd
            mJ <- mJ + t(Xd)%*%Sigmad.inv%*%D1Nd%*%t(D1Nd)%*%Sigmad.inv%*%Xd
        }
    
        R <- solve(mR)     
    
        mA <- 0  
        mB <- 0  
        mC <- 0  
        mD <- 0  
        mE <- 0  
        mG <- 0  
        mH <- 0  
        mK <- 0  
        mL <- 0  
        mM <- 0  
        mN <- 0  
        mP <- 0  
        mQ <- 0  
        mR <- 0  
        mS <- 0  
        mT <- 0  
        mV <- 0  
        mW <- 0  
    
        for(d in 1:D) {      
            if (d==1) {
                Inicio <-1
                Pr <-1
            }
            if (d!=1) {
                Pr <- (ndcum[mdcum[d-1]]+1)
                Inicio <-mdcum[d-1]+1
            }
            Fin  <- ndcum[mdcum[d]]
            Nd <- Fin-Pr+1
 
            Wd <- W[Pr:Fin,Pr:Fin]
            yd <- Y[Pr:Fin]
            Xd <- X[Pr:Fin,]
                   
            D1Nd <- matrix(0,Nd,md[d])
            i <- 1
            for(k in 1:md[d]) {
                for(j in 1:ndi[Inicio+k-1]) {
                    D1Nd[i,k]<-1 
                    i<- i+1
                }
            } 
       
            UnoNd <-as.matrix(rep(1,Nd))
                       
            mA <- mA + t(yd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%yd
            mB <- mB + t(yd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%Xd       
            mC <- mC + t(Xd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%yd
        
            T3 <- t(yd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%UnoNd%*%t(UnoNd)%*%Sd.inv[Pr:Fin,Pr:Fin]
        
            mD <- mD + T3%*%yd
            mE <- mE + T3%*%Xd
        
            T4 <- Sd.inv[Pr:Fin,Pr:Fin] - Sd.inv[Pr:Fin,Pr:Fin]%*%Xd%*%R%*%t(Xd)%*%Sd.inv[Pr:Fin,Pr:Fin]
        
            mG <- mG + t(UnoNd)%*%T4%*%UnoNd                  
            mH <- mH + sum(diag(t(D1Nd)%*%T4%*%D1Nd))
            
            T5 <- t(yd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%D1Nd%*%t(D1Nd)%*%Sd.inv[Pr:Fin,Pr:Fin]
            
            mK <- mK + T5%*%yd
            mL <- mL + T5%*%Xd
            
            T6 <- t(UnoNd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%UnoNd
                      
            mM <- mM + T6%*%T6
            mN <- mN + T6%*%t(UnoNd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%Xd%*%R%*%t(Xd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%UnoNd
            mP <- mP + t(UnoNd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%Xd%*%R%*%mF%*%R%*%t(Xd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%UnoNd
            
            T7 <- t(D1Nd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%Xd%*%R
           
            T8 <- t(D1Nd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%UnoNd%*%t(UnoNd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%D1Nd
            
            mQ <- mQ + sum(diag(T8))
            mR <- mR + sum(diag(T7%*%t(Xd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%UnoNd%*%t(UnoNd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%D1Nd))
            mS <- mS + sum(diag(T7%*%mF%*%R%*%t(Xd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%D1Nd))
            
            mT <- mT + sum(diag(t(D1Nd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%D1Nd%*%t(D1Nd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%D1Nd))
            mV <- mV + sum(diag(T7%*%t(Xd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%D1Nd%*%t(D1Nd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%D1Nd))
            mW <- mW + sum(diag(T7%*%mJ%*%R%*%t(Xd)%*%Sd.inv[Pr:Fin,Pr:Fin]%*%D1Nd))
            
        }

        S <- matrix(0, nrow=2, ncol=1)
        F <- matrix(0, nrow=2, ncol=2)
        F3 <- matrix(0, nrow=3, ncol=3)
    
        sigma0S <- 1/(n-p)*(mA-(mB%*%R%*%mC))

        S[1,1] <- - mG/2 + mD/(2*sigma0) - (mE%*%R%*%mC)/sigma0 + (mB%*%R%*%mF%*%R%*%mC)/(2*sigma0)
        S[2,1] <- - mH/2 + mK/(2*sigma0) - (mL%*%R%*%mC)/sigma0 + (mB%*%R%*%mJ%*%R%*%mC)/(2*sigma0)

        F[1,1] <- mM/2 - mN + mP/2     
        F[1,2] <- mQ/2 - mR + mS/2       
        F[2,1] <- F[1,2]       
        F[2,2] <- mT/2 -mV + mW/2       
        
        F.inv <- solve(F)
        d <- F.inv%*%S
        F1 <- F1 + d[1]
        F2 <- F2 + d[2]
        
        dif <- rbind(sigma0S-sigma0,d*as.vector(sigma0S))
        sigma <- rbind(sigma0S, sigma0S*F1,sigma0S*F2)
        
        F3[1,1] <- (n-p)/(2*sigma0*sigma0)
        F3[1,2] <- mG/(2*sigma0)
        F3[1,3] <- mH/(2*sigma0)
        F3[2,1] <- F3[1,2]      
        F3[2,2] <- mM/2 - mN + mP/2     
        F3[2,3] <- mQ/2 - mR + mS/2       
        F3[3,1] <- F3[1,3]       
        F3[3,2] <- F3[2,3]       
        F3[3,3] <- mT/2 -mV + mW/2       
        
        F3.inv <- solve(F3)

        
        sigma0 <- sigma[1]
        sigma1 <- sigma[2]
        sigma2 <- sigma[3] 

        if(abs(dif[1])<0.00001 & abs(dif[2])<0.00001 & abs(dif[3])<0.00001)
            break

    }
    return(list(sigma0,sigma1,sigma2,F3.inv,ITER,R))

}
