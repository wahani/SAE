###############################################################################
###############################################################################
###
###                             Matriz Omegad                                  
###                            Proyecto SAMPLE                                 
###                           26 Marzo de 2010                                 
###

### AUTOR: Laureano Santamaria Arana

### Editado por:
### con fecha:

#Matriz Omegad y su derivada  
    
Calcula_Omegad <- function(Elem, rho) {
             
    Omegad<-matrix(0,nrow=Elem,ncol=Elem)
    Omegad[lower.tri(Omegad)]<-rho^sequence((Elem-1):1)
    Omegad<-Omegad+t(Omegad)
    diag(Omegad)<-1
    Omegad <- (1/(1-rho^2))*Omegad
    
    return(as.matrix(Omegad))
    
}
              
Deriva_Omegad <- function(Elem, rho, Omegad) {
               
    OmegadPrima<-matrix(0,nrow=Elem,ncol=Elem)
    OmegadPrima[lower.tri(OmegadPrima)] <- sequence((Elem-1):1)*rho^(sequence((Elem-1):1)-1)
    OmegadPrima <- OmegadPrima+t(OmegadPrima)
    OmegadPrima <- (1/(1-rho^2))*OmegadPrima
    OmegadPrima <- OmegadPrima + (2*rho/(1-rho^2))*Omegad
          
    return(as.matrix(OmegadPrima))
}

Inversa_Omegad <- function(Elem, rho) {
               
    Imd <- diag(Elem)
    E <- diag(Elem)
    E[1,1] <- 0
    E[Elem,Elem] <- 0
    F <- diag(Elem)
    for(i in 1:Elem) {
        F[i,i] <- 0
        if (i>1) {
            F[i,i-1] <- 1
        }
        if (i<Elem) {
            F[i,i+1] <- 1            
        }
    }
    OmegadInversa <- matrix(0,nrow=Elem,ncol=Elem)
    OmegadInversa <- Imd + (rho*rho*E) - (rho*F)
          
    return(as.matrix(OmegadInversa))
}


pvalue <- function(beta0, fit) {

    z <- abs(beta0)/sqrt(as.vector(diag(fit[[3]])))
    pval <- 2*pnorm(z, lower.tail=F)

    return( pval )
}

Interval.autocorr <- function(fit, conf=0.95) {
    alfa <- 1-conf
    k <- 1-alfa/2
    z <- qnorm(k)

    Finv <- fit[[2]]
    sigma.std.err <- z*sqrt(Finv[1,1])
    sigma1.std.err <- z*sqrt(Finv[2,2])
    sigma2.std.err <- z*sqrt(Finv[3,3])
    rho.std.err <- z*sqrt(Finv[4,4])
    beta.std.err <- z*sqrt(as.vector(diag(fit[[3]])))

    return( list(sigma.std.err, sigma1.std.err, sigma2.std.err, rho.std.err, beta.std.err) )
}

Interval.Indep <- function(fit, conf=0.95) {
    alfa <- 1-conf
    k <- 1-alfa/2
    z <- qnorm(k)

    Finv <- fit[[2]]
    sigma.std.err <- z*sqrt(Finv[1,1])
    sigma1.std.err <- z*sqrt(Finv[2,2])
    sigma2.std.err <- z*sqrt(Finv[3,3])
    beta.std.err <- z*sqrt(as.vector(diag(fit[[3]])))

    return( list(sigma.std.err, sigma1.std.err, sigma2.std.err, beta.std.err) )
}


Calcular.Media <- function(X, D,  md, ndi) { 

   mdcum <- cumsum(md)
   Cabezal <- 0 
   nf <- ncol(X)
   Media <- matrix(0, nrow=mdcum[D], ncol=nf)
    
   for(d in 1:D) {             
        for(j in 1:md[d]) {
                if (d==1) {
                    Inicio <-1
                    size <- ndi[j]
                }
                if (d!=1) {
                    size <- ndi[mdcum[d-1]+j] 
                    Inicio <-mdcum[d-1]+1
                }
                Media[Inicio+j-1,1] <- 1
                for(k in 2:nf) {
                    m <- 0
                    for(i in 1:size) {
                       ind <- Cabezal + i
                       m <- m + X[ind,k]
                    }
                    m <- m/size
                    Media[Inicio+j-1,k] <- m
                }
                Cabezal <- Cabezal + size
        }
    }
   return(Media)
}

Calcular.Media.Y <- function(Y, D,  md, ndi) { 

   mdcum <- cumsum(md)
   Cabezal <- 0 
   Media <- matrix(0, nrow=mdcum[D], ncol=1)
    
   for(d in 1:D) {             
        for(j in 1:md[d]) {
                if (d==1) {
                    Inicio <-1
                    size <- ndi[j]
                }
                if (d!=1) {
                    size <- ndi[mdcum[d-1]+j] 
                    Inicio <-mdcum[d-1]+1
                }
                m <- 0
                for(i in 1:size) {
                    ind <- Cabezal + i
                    m <- m + Y[ind]
                }
                m <- m/size
                Media[Inicio+j-1] <- m
                Cabezal <- Cabezal + size
        }
    }
   return(Media)
}

Calcular.Yeblup <- function(X, Y, W, D, md, ndi, Beta, sigma0, sigma1, sigma2, rho, Mxp) { 
 
    F1 <- sigma1/sigma0  
    F2 <- sigma2/sigma0
    
    mdcum <- cumsum(md)
    ndcum <- cumsum(ndi)
    
    u1 <- rep(1,D) 
    
    for(d in 1:D) {      
        if (d==1) {
            Inicio <-1
            P <-1
            Nns <- mdcum[d]
        }
        if (d!=1) {
            P <- (ndcum[mdcum[d-1]]+1)
            Inicio <-mdcum[d-1]+1
            Nns <- mdcum[d]-mdcum[d-1]
        }
        Fin  <- ndcum[mdcum[d]]
        Nd <- Fin-P+1
 
        Wd <- W[P:Fin,P:Fin]
        yd <- as.matrix(Y[P:Fin],nrow=Nd,ncol=1)
        Xd <- X[P:Fin,]
                   
        D1Nd <- matrix(0,Nd,md[d])
        i <- 1
        for(k in 1:md[d]) {
            for(j in 1:ndi[Inicio+k-1]) {
                D1Nd[i,k]<-1 
                i<- i+1
            }
        } 
        Imd<-diag(md[d])
        OmegadInv <- Inversa_Omegad(md[d], rho)
        Omegad <- Calcula_Omegad(md[d], rho)
 
        sld.inv <- solve(OmegadInv+F2*t(D1Nd)%*%Wd%*%D1Nd)
        Ld.inv <- Wd-F2*Wd%*%D1Nd%*%sld.inv%*%t(D1Nd)%*%Wd
       
        UnoNd <-as.matrix(rep(1,Nd))

        T1 <- F1*Ld.inv%*%UnoNd%*%t(UnoNd)%*%Ld.inv
        T2 <- 1+(F1*t(UnoNd)%*%Ld.inv%*%UnoNd)
        
        Sigmad.inv <- Ld.inv - (T1/T2[1,1])
       
        u1d <- F1*t(UnoNd)%*%Sigmad.inv%*%(yd-Xd%*%Beta)
        u1[d] <- u1d
        
        u2d <- F2*Omegad%*%t(D1Nd)%*%Sigmad.inv%*%(yd-Xd%*%Beta)
        if (d==1) {
            u2 <- u2d
            U1 <- rep(u1[d],Nns) 

        }
        if (d!=1) {
            u2 <- rbind(u2,u2d) 
            U1 <- c(U1,rep(u1[d],Nns))

        }
    }     
    
    yblup <-  Mxp%*%Beta + U1 + u2

    return(yblup)   
}

Calcular.Yeblup.Indep <- function(X, Y, W, D, md, ndi, Beta, sigma0, sigma1, sigma2, Mxp) { 
 
    n <- nrow(X)
    F1 <- sigma1/sigma0  
    F2 <- sigma2/sigma0
    
    mdcum <- cumsum(md)
    ndcum <- cumsum(ndi)
    
    u1 <- rep(1,D) 
    
    for(d in 1:D) {      
        if (d==1) {
            Inicio <-1
            P <-1
            Nns <- mdcum[d]
        }
        if (d!=1) {
            P <- (ndcum[mdcum[d-1]]+1)
            Inicio <-mdcum[d-1]+1
            Nns <- mdcum[d]-mdcum[d-1]
        }
        Fin  <- ndcum[mdcum[d]]
        Nd <- Fin-P+1
 
        Wd <- W[P:Fin,P:Fin]
        yd <- Y[P:Fin]
        Xd <- X[P:Fin,]
                   
        D1Nd <- matrix(0,Nd,md[d])
        i <- 1
        for(k in 1:md[d]) {
            for(j in 1:ndi[Inicio+k-1]) {
                D1Nd[i,k]<-1 
                i<- i+1
            }
        } 
        Imd<-diag(md[d])
       
        sld.inv <- solve(Imd+F2*t(D1Nd)%*%Wd%*%D1Nd)
        Ld.inv <- Wd-F2*Wd%*%D1Nd%*%sld.inv%*%t(D1Nd)%*%Wd
       
        UnoNd <-as.matrix(rep(1,Nd))

        T1 <- F1*Ld.inv%*%UnoNd%*%t(UnoNd)%*%Ld.inv
        T2 <- 1+(F1*t(UnoNd)%*%Ld.inv%*%UnoNd)
        
        Sigmad.inv <- Ld.inv - (T1/T2[1,1])
       
        u1d <- F1*t(UnoNd)%*%Sigmad.inv%*%(yd-Xd%*%Beta)
        u1[d] <- u1d
        
        u2d <- F2*t(D1Nd)%*%Sigmad.inv%*%(yd-Xd%*%Beta)
        if (d==1) {
            u2 <- u2d
            U1 <- rep(u1[d],Nns) 

        }
        if (d!=1) {
            u2 <- rbind(u2,u2d) 
            U1 <- c(U1,rep(u1[d],Nns))
        }
    } 
    
    yblup <-  Mxp%*%Beta + U1 + u2

    return(yblup)   
}

Calcular.Semilla <- function(X, Y, D, md, ndi) { 

    n <- nrow(X)
    
    mdcum <- cumsum(md)
    ndcum <- cumsum(ndi)
    B1 <- 0
    B2 <- 0 

    for(d in 1:D) {      
        if (d==1) {
            Inicio <-1
            P <-1
        }
        if (d!=1) {
            P <- (ndcum[mdcum[d-1]]+1)
            Inicio <-mdcum[d-1]+1
        }
        Fin  <- ndcum[mdcum[d]]
        Nd <- Fin-P+1
 
        yd <- Y[P:Fin]
        Xd <- X[P:Fin,]     
       
        B1 <- B1 + t(Xd)%*%Xd
        B2 <- B2 + t(Xd)%*%yd
    }
    
    Beta0 <- solve(B1)%*%B2
    V <- 0

    for(d in 1:D) {      
        if (d==1) {
            Inicio <-1
            P <-1
        }
        if (d!=1) {
            P <- (ndcum[mdcum[d-1]]+1)
            Inicio <-mdcum[d-1]+1
        }
        Fin  <- ndcum[mdcum[d]]
        Nd <- Fin-P+1
 
        yd <- Y[P:Fin]
        Xd <- X[P:Fin,]     
       
        T1 <- yd - Xd%*%Beta0       
        V <- V + t(T1)%*%T1
        
        B1 <- B1 + t(Xd)%*%Xd
        B2 <- B2 + t(Xd)%*%yd
    }
    
    V <- V/(n-1)
    
    return(list(V/3,V/3,V/3,0.5))
}
