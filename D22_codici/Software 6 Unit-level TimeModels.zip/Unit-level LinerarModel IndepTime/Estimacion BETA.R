###############################################################################
###############################################################################
###
###                    C�lculo de BETA para modelo de area                     
###                              Proyecto SAMPLE                               
###                              Proyecto SAMPLE                               
###                               26 Marzo 2009                                
###

### AUTOR: Laureano Santamaria Arana

### Editado por:
### con fecha:
### cambios realizados:         

### Comentarios: 



BETA.U.area <- function(X, Y, W, D, md, ndi, sigma0, sigma1, sigma2) { 
    
     
    n <- nrow(X)
    F1 <- sigma1/sigma0  
    F2 <- sigma2/sigma0

    
    Sd.inv<-matrix(0, nrow=n, ncol=n)
    
    mdcum <- cumsum(md)
    ndcum <- cumsum(ndi)
    B1 <- 0
    B2 <- 0  
    
    for(d in 1:D) {      
        if (d==1) {
            Inicio <-1
            P <-1
        }
        if (d!=1) {
            P <- (ndcum[mdcum[d-1]]+1)
            Inicio <-mdcum[d-1]+1
        }
        Fin  <- ndcum[mdcum[d]]
        Nd <- Fin-P+1
 
        Wd <- W[P:Fin,P:Fin]
        yd <- Y[P:Fin]
        Xd <- X[P:Fin,]
                   
        D1Nd <- matrix(0,Nd,md[d])
        i <- 1
        for(k in 1:md[d]) {
            for(j in 1:ndi[Inicio+k-1]) {
                D1Nd[i,k]<-1 
                i<- i+1
            }
        } 
        Imd<-diag(md[d])
       
        sld.inv <- solve(Imd+F2*t(D1Nd)%*%Wd%*%D1Nd)
        Ld.inv <- Wd-F2*Wd%*%D1Nd%*%sld.inv%*%t(D1Nd)%*%Wd
       
        UnoNd <-as.matrix(rep(1,Nd))

        T1 <- F1*Ld.inv%*%UnoNd%*%t(UnoNd)%*%Ld.inv
        T2 <- 1+(F1*t(UnoNd)%*%Ld.inv%*%UnoNd)
        
        Sigmad.inv <- Ld.inv - (T1/T2[1,1])  
        Sd.inv[P:Fin,P:Fin] <- Sigmad.inv
        
        B1 <- B1 + t(Xd)%*%Sigmad.inv%*%Xd
        B2 <- B2 + t(Xd)%*%Sigmad.inv%*%yd
       

    }
    
    Beta <- solve(B1)%*%B2  
    
    return(Beta)
    
}
