###############################################################################
###
### This function fits a unit level model to the log of the welfare variable
### and obtains EB estimators of FGT poverty measures of order 1 and 2 
### (poverty incidence and poverty gap) when the out-of-sample values of
### auxiliary variables are available.
###
### Work for European project SAMPLE
###
### Author: Isabel Molina
### File name: FGTpovertyEB.R
### Updated: February 8th, 2011
###
###############################################################################

FGTpovertyEB<-function(dom,seldomain=unique(dom),Xrdtot,welfare,Xs,weight,z=0.6*median(welfare),L=50,seed=Sys.time()){

# Load library required to fit a mixed model

library(nlme)

# Set the seed for random number generation, 
# required for the Monte Carlo approximation of the EB method.

set.seed(seed)

# Number of domains for which EB estimators of poverty measures are required 
# called (target domains)

I<-length(unique(seldomain))

# Total number of domains with sample data

D<-length(unique(dom))

# Number of auxiliary variables (including the constant)

p<-dim(Xs)[2]

# Sample sizes and out-of-sample sizes of target domains

nd<-rep(0,D)
rd<-rep(0,D)

for (i in 1:I){
  nd[seldomain[i]]<-sum(dom==seldomain[i])
  rd[seldomain[i]]<-dim(Xrdtot[[i]])[1]
}

# Take logarithm of welfare after adding a constant to make it positive

m<-abs(min(welfare))+1 
welfaret<-welfare+m
ys<-log(welfaret)

# Fit the nested-error model to sample data by REML method using function lme 
# from library nlme. 

fit.EB<-lme(ys~-1+Xs,random=~1|as.factor(dom),method="REML")

# Create a list object containing different results from the model fit.

Resultsfit<-list(Summary=summary(fit.EB),FixedEffects=fixed.effects(fit.EB),RandomEffects=random.effects(fit.EB),ResVar=fit.EB$sigma,RandomEffVar=as.numeric(VarCorr(fit.EB)[1,1]),Loglike=fit.EB$logLik,RawResiduals=fit.EB$residuals[1:n])

# Save some of the results of the fitting method in variables

betaest<-fixed.effects(fit.EB)# Vector of model coefficients (size p)
upred<-random.effects(fit.EB) # Predicted random effects: Watch out! It is not a vector, it is a matrix with 1 column
sigmae2est<-fit.EB$sigma^2    # Estimated error variance
sigmau2est<-as.numeric(VarCorr(fit.EB)[1,1]) # VarCorr(fit2) is the estimated cov. matrix of the model random components

# EB method starts: Generate L vectors of non-sample values of the response 
# from their conditional distribution given the sample data and calculate 
# empirical values of EB estimators.

# Matrices with poverty incidences and gaps for the L simulations in the EB method
povinc<-matrix(0,nr=D,nc=L)
povgap<-matrix(0,nr=D,nc=L)

# Vectors with final EB estimators
povinc.EB<-rep(0,D)
povgap.EB<-rep(0,D)

# Time counter initialization
time1<-Sys.time()
time1

for (i in 1:I){    # Cycle for target domains

  # Print order of target domain
  cat("Domain num.",i,"\n")
  
  # Code of target domain  
  d<-seldomain[i]   
  
  # Matrix with the values of the p auxiliary variables for the out-of-sample 
  # observations in the i-th target domain
  Xrd<-Xrdtot[[i]]  

  # Get sample values for target domain
  ysd<-ys[dom==d]

  # Compute conditional means for out-of-sample units
  mudpred<-Xrd%*%matrix(betaest,nr=p,nc=1)+upred[d,1]

  # The conditional distribution of (non-sample data given sample data) in the 
  # EB method can be expressed as a new nested-error model with different random 
  # effects variance. We calculate this random effects variance (called sigmav2)

  gammad<-sigmau2est/(sigmau2est+sigmae2est/nd[d])
  sigmav2<-sigmau2est*(1-gammad)

  for (ell in 1:L){   ### Start of Monte Carlo simulations for EB method

    # Generate random effect for target domain d
    vd<-rnorm(1,0,sqrt(sigmav2))

    # Generate random errors for all out-of-sample units in target domain d
    ed<-rnorm(rd[d],0,sqrt(sigmae2est))

    # Compute vector of out-if-sample responses
    yrdpred<-mudpred+vd+ed

    # Merge non-sample and sample values (full population or census) for domain d
    ydnew<-c(ysd,yrdpred)

    # Compute domain poverty measures using population values
    Ednew<-exp(ydnew)-m
    povinc[d,ell]<-mean(Ednew<z)
    povgap[d,ell]<-mean((Ednew<z)*(z-Ednew)/z)

  }  # End of Monte Carlo simulations for EB method

  # EB predictors of poverty measures (averages over the L Monte Carlo simulations)

  povinc.EB[d]<-mean(povinc[d,])
  povgap.EB[d]<-mean(povgap[d,])

} # End of cycle for province index

time2 <- Sys.time()   # Current time
ComputTime<-difftime(time2,time1,units="mins")  # Total time spent by EB method

# Results

EstimatedPoverty<-data.frame(Domain=seldomain,PovInc=100*povinc.EB[seldomain],PovGap=100*povgap.EB[seldomain])

return (list(EstimatedPoverty=EstimatedPoverty,ComputTime=ComputTime,Resultsfit=Resultsfit))

} #End of function FGTpovertyEB
