###############################################################################
###
### This function obtains estimators of the MSEs of the EB estimators of FGT 
### poverty measures of order 1 (poverty incidence) and order 2 (poverty gap) 
### by a parametric bootstrap method. Population values of auxiliary variables  
### are required.
###
### Work for European project SAMPLE
###
### Author: Isabel Molina
### File name: PBMSE_EB.R
### Updated: February 8th, 2011
###
###############################################################################

PBMSE.EB<-function(dom,seldomain=unique(dom),Xrdtot,welfare,Xs,weight,z=0.6*median(welfare),B=50,LB=50,seed=Sys.time()){

# Load library required to fit a mixed model

library(nlme)

# Set the seed for random number generation, 
# required for the Monte Carlo approximation of the EB method.

set.seed(seed)

# Number of domains for which EB estimators of poverty measures are required 
# called (target domains)

I<-length(unique(seldomain))

# Total number of sample observations

n<-length(welfare) 

# Total number of domains with sample data

D<-length(unique(dom)) 

# Number of auxiliary variables (including the constant)

p<-dim(Xs)[2]

# Sample sizes and out-of-sample sizes of target domains

nd<-rep(0,D) 
rd<-rep(0,D)

for (i in 1:I){
  nd[seldomain[i]]<-sum(dom==seldomain[i])
  rd[seldomain[i]]<-dim(Xrdtot[[i]])[1]
}

# Take logarithm of welfare after adding a constant to make it positive

m<-abs(min(welfare))+1 
welfaret<-welfare+m 
ys<-log(welfaret)

# Fit the nested-error model to sample data by REML method using function lme 
# from library nlme. 

fit.EB<-lme(ys~-1+Xs,random=~1|as.factor(dom),method="REML")

# Save some of the results of the fitting method in variables

betaest<-fixed.effects(fit.EB)# Vector of model coefficients (size p) 
upred<-random.effects(fit.EB) # Predicted random effects: Watch out! It is not a vector, it is a matrix with 1 column
sigmae2est<-fit.EB$sigma^2    # Estimated error variance
sigmau2est<-as.numeric(VarCorr(fit.EB)[1,1]) # VarCorr(fit2) is the estimated cov. matrix of the model random components

# Initialize vectors with the bootstrap MSEs of EB estimators

MSEpropsum.B<-rep(0,D) 
MSEgapsum.B<-rep(0,D)
MSEpovincEB.B<-rep(0,D) 
MSEpovgapEB.B<-rep(0,D)

# Time counter initialization
time1<-Sys.time() 

for (b in 1:B){   ### Start of bootstrap cycle

  # Print bootstrap iteration
  
  cat("Bootstrap iteration",b,"\n")

  # We will generate a bootstrap population by generating sample and 
  # out-of-sample elements and calculate true poverty measures.

  ys.B<-rep(0,n)   # Boostrap sample vector

  # Initialize vectors with true poverty measures
  truepovinc.B<-rep(0,D)
  truepovgap.B<-rep(0,D)

  # Initialize vectors with estimated poverty measures
  povinc.B<-matrix(0,nr=D,nc=LB)
  povgap.B<-matrix(0,nr=D,nc=LB)
  povinc.EB.B<-rep(0,D)
  povgap.EB.B<-rep(0,D)

  ud.B<-rep(0,D)    # Bootstrap random effects
  nd<-rep(0,D)      # Vector with sample sizes of provinces

  # Generate sample elements (for all domains)

  for (d in 1:D){

    # Take sample elements

    Xsd<-Xs[dom==d,]

    # Calculate the cummulated sample sizes

    nd[d]<-sum(dom==d)

    # Generate sample values of y from the fitted model

    esd.B<-rnorm(nd[d],0,sqrt(sigmae2est))
    ud.B[d]<-rnorm(1,0,sqrt(sigmau2est))
    musd.B<-Xsd%*%matrix(betaest,nr=p,nc=1)
    ys.B[dom==d]<-musd.B+ud.B[d]+esd.B
  }

  # Take the bootstrap sample data and fit the nested-error model to it

  fit.B<-lme(ys.B~-1+Xs,random=~1|as.factor(dom),method="REML")
  betaest.B<-fixed.effects(fit.B)
  upred.B<-random.effects(fit.B)
  sigmae2est.B<-fit.B$sigma^2
  sigmau2est.B<-as.numeric(VarCorr(fit.B)[1,1])

  # Generate non-sample values only for selected domains

  for (i in 1:I){

    # Print order of target domain
    cat("Domain num.",i,"\n")

    # Target domain
    d<-seldomain[i]
    
    # Matrix with the values of the p auxiliary variables for the out-of-sample 
    # observations in i-th target domain
    Xrd<-Xrdtot[[i]]

    # Vector of out-of-sample random errors in target domain d
    erd.B<-rnorm(rd[d],0,sqrt(sigmae2est))

    # Vector of out-of-sample marginal means
    murd.B<-Xrd%*%matrix(betaest,nr=p,nc=1)

    # Vector of out-of-sample responses
    yrd.B<-murd.B+ud.B[d]+erd.B
    Erd.B<-exp(yrd.B)-m

    # Merge sample and non-sample elements for target domain d

    ysd.B<-ys.B[dom==d]
    Esd.B<-exp(ysd.B)-m
    Ed.B<-c(Erd.B,Esd.B)

    # Calculate true domain poverty incidence and gap for target domain d

    truepovinc.B[d]<-mean(Ed.B<z)
    truepovgap.B[d]<-mean((Ed.B<z)*(z-Ed.B)/z)

    # Compute EB predictors for each bootstrap sample

    # Conditional mean for non-sample units
    mudpred.B<-Xrd%*%matrix(betaest,nr=p,nc=1)+upred.B[d,1]

    # The conditional distribution of (non-sample data given sample data) in the 
    # EB method can be expressed as a new nested-error model with different random 
    # effects variance. We calculate this random effects variance (called sigmav2)

    gammad.B<-sigmau2est.B/(sigmau2est.B+sigmae2est.B/nd[d])
    sigmav2.B<-sigmau2est.B*(1-gammad.B)

    for (ellb in 1:LB){   ### Monte Carlo approximation of EB predictors

      # Generate random effect for target domain d
      vd.B<-rnorm(1,0,sqrt(sigmav2.B))
      
      # Generate random errors for all out-of-sample units in target domain d
      ed.B<-rnorm(rd[d],0,sqrt(sigmae2est.B))

      # Compute vector of out-if-sample responses
      yrdpred.B<-mudpred.B+vd.B+ed.B
      
      # Merge non-sample and sample values (full population or census) for domain d
      ydnew.B<-c(ysd.B,yrdpred.B)
      Ednew.B<-exp(ydnew.B)-m

      # EB predictors of poverty measures for each simulation

      povinc.B[d,ellb]<-mean(Ednew.B<z)
      povgap.B[d,ellb]<-mean((Ednew.B<z)*(z-Ednew.B)/z)

    }  # End of Monte Carlo generations

    # EB predictors of poverty measures

    povinc.EB.B[d]<-mean(povinc.B[d,])
    povgap.EB.B[d]<-mean(povgap.B[d,])

    # Cumulated squared errors for Bootstrap MSE

    MSEpropsum.B[d]<-MSEpropsum.B[d]+(povinc.EB.B[d]-truepovinc.B[d])^2
    MSEgapsum.B[d]<-MSEgapsum.B[d]+(povgap.EB.B[d]-truepovgap.B[d])^2

  } # En of cycle for target area

}  # End of the bootstrap cycle

time2 <- Sys.time() 
time2<-difftime(time2,time1,units="mins")
print(time2)

# Bootstrap MSEs 

for (i in 1:I){

  d<-seldomain[i]

  # Bootstrap MSS of EB estimators
  MSEpovincEB.B[d]<-MSEpropsum.B[d]/B
  MSEpovgapEB.B[d]<-MSEgapsum.B[d]/B

}

# Save results

Results<-data.frame(Domain=seldomain,SampSize=nd[seldomain],PBMSEpovinc=MSEpovincEB.B[seldomain]*10000,PBMSEpovgap=MSEpovgapEB.B[seldomain]*10000)

return (Results)

} # End of function PBMSE.EB
