###############################################################################
###
###          Area level Partitioned F-H model with correlated time effects
###                             Pagliarella model 2
###
###
### AUTOR: Maria Chiara Pagliarella
### File name: ICcorr.R
### Updated: August 2010
###
### WORKING PROGRESS
###############################################################################


Interval.corr <- function(Fisher, conf=0.95) {

    alfa <- 1-conf
    k <- 1-alfa/2
    z <- qnorm(k)
    
    Finv <- solve(Fisher[[2]])
    
    sigma.a.std.err <- z*sqrt(Finv[1,1])
    sigma.b.std.err <- z*sqrt(Finv[2,2])
    sigma.ab.std.err <- z*sqrt(Finv[1,1] + Finv[2,2] - 2*Finv[1,2])
    
    rho.std.err <- z*sqrt(Finv[3,3])
    
    beta.std.err <- z*sqrt(as.vector(diag(Fisher[[5]])))
    
    infbeta <- beta0.hat - beta.std.err
    supbeta <- beta0.hat + beta.std.err
    testbeta <- beta0.hat - beta.std.err < 0 & beta0.hat + beta.std.err > 0
    
    infsigmaua <- sigmaua.hat - sigma.a.std.err
    supsigmaua <- sigmaua.hat + sigma.a.std.err
    testsigmaua <- sigmaua.hat - sigma.a.std.err < 0 & sigmaua.hat + sigma.a.std.err > 0
    
    infsigmaub <- sigmaub.hat - sigma.b.std.err
    supsigmaub <- sigmaub.hat + sigma.b.std.err
    testsigmaub <- sigmaub.hat - sigma.b.std.err < 0 & sigmaub.hat + sigma.b.std.err > 0
    
    infdif.sigma <- (sigmaua.hat - sigmaub.hat) - sigma.ab.std.err
    supdif.sigma <- (sigmaua.hat - sigmaub.hat) + sigma.ab.std.err
    testdif.sigma <- (sigmaua.hat - sigmaub.hat) - sigma.ab.std.err < 0 & (sigmaua.hat - sigmaub.hat) + sigma.ab.std.err > 0
    
    
    infrho <- rho.hat - rho.std.err
    suprho <- rho.hat + rho.std.err
    testrho <- rho.hat - rho.std.err < 0 & rho.hat + rho.std.err > 0
        
    return(list(
    sigma.a.std.err, sigma.b.std.err, sigma.ab.std.err, 
    rho.std.err, beta.std.err,
    
    infbeta, supbeta, testbeta,
    
    infsigmaua, supsigmaua, testsigmaua,
    infsigmaub, supsigmaub, testsigmaub,
    infdif.sigma, supdif.sigma, testdif.sigma,
    
    infrho, suprho, testrho))
}

pvalueBeta.corr <- function(beta0.hat, Fisher) {
    
    z <- abs(beta0.hat) / sqrt(as.vector(diag(Fisher[[5]])))
    p.beta <- pnorm(z, lower.tail=F)
    
    return( 2*p.beta )
}
