###############################################################################
###
###          Area level Patitioned F-H model with independent time effects
###                             Pagliarella model 1
###
###
### AUTOR: Maria Chiara Pagliarella
### File name: IC.R
### Updated: February 2010
###
### WORKING PROGRESS
###############################################################################


Interval <- function(Fisher, conf=0.95) {

    alfa <- 1-conf
    k <- 1-alfa/2
    z <- qnorm(k)
    
    Finv <- solve(Fisher[[3]])
    
    sigma.a.std.err <- z*sqrt(Finv[1,1])
    sigma.b.std.err <- z*sqrt(Finv[2,2])
    sigma.ab.std.err <- z*sqrt(Finv[1,1]+Finv[2,2]-2*Finv[1,2])
    
    beta.std.err <- z*sqrt(as.vector(diag(Fisher[[5]])))
    
    infbeta <- beta0.hat-beta.std.err 
    supbeta <- beta0.hat+beta.std.err 
    testbeta <- beta0.hat-beta.std.err<0 & beta0.hat+beta.std.err>0
   
    infsigmaua <- sigmaua.hat-sigma.a.std.err
    supsigmaua <- sigmaua.hat+sigma.a.std.err
    testsigmaua <- sigmaua.hat-sigma.a.std.err<0 & sigmaua.hat+sigma.a.std.err>0
    
    infsigmaub <- sigmaub.hat-sigma.b.std.err
    supsigmaub <- sigmaub.hat+sigma.b.std.err
    testsigmaub <- sigmaub.hat-sigma.b.std.err<0 & sigmaub.hat+sigma.b.std.err>0
    
    infdif <- (sigmaua.hat-sigmaub.hat)-sigma.ab.std.err
    supdif <- (sigmaua.hat-sigmaub.hat)+sigma.ab.std.err
    testdif <- (sigmaua.hat-sigmaub.hat)-sigma.ab.std.err<0 & (sigmaua.hat-sigmaub.hat)+sigma.ab.std.err>0
   
    
    
    return( list(sigma.a.std.err, sigma.b.std.err, sigma.ab.std.err, beta.std.err, 
    infbeta, supbeta, testbeta,
    infsigmaua, supsigmaua, testsigmaua,
    infsigmaub, supsigmaub, testsigmaub,
    infdif, supdif, testdif) )
}

pvalueBeta <- function(beta0.hat, Fisher) {
    
    z <- abs(beta0.hat)/sqrt(as.vector(diag(Fisher[[5]])))
    p.beta <- pnorm(z, lower.tail=F)
    
    return( 2*p.beta )
}
