###############################################################################
###
###          Area level Partitioned F-H model with correlated time effects
###                             Pagliarella model 3
###
###
### AUTOR: Maria Chiara Pagliarella
### File name: IC2corr.R
### Updated: July 2010
###
### WORKING PROGRESS
###############################################################################


Interval.2corr <- function(Fisher, conf=0.95) {

    alfa <- 1-conf
    k <- 1-alfa/2
    z <- qnorm(k)
    
    Finv <- solve(Fisher[[2]])
    
    sigma.a.std.err <- z*sqrt(Finv[1,1])
    sigma.b.std.err <- z*sqrt(Finv[3,3])
    sigma.ab.std.err <- z*sqrt(Finv[1,1] + Finv[3,3] - 2*Finv[1,3])
    
    rho.a.std.err <- z*sqrt(Finv[2,2])
    rho.b.std.err <- z*sqrt(Finv[4,4])
    rho.ab.std.err <- z*sqrt(Finv[2,2] + Finv[4,4] - 2*Finv[2,4])
    
    beta.std.err <- z*sqrt(as.vector(diag(Fisher[[5]])))
    
    infbeta <- beta0.hat - beta.std.err
    supbeta <- beta0.hat + beta.std.err
    testbeta <- beta0.hat - beta.std.err < 0 & beta0.hat + beta.std.err > 0
    
    infsigmaua <- sigmaua.hat - sigma.a.std.err
    supsigmaua <- sigmaua.hat + sigma.a.std.err
    testsigmaua <- sigmaua.hat - sigma.a.std.err < 0 & sigmaua.hat + sigma.a.std.err > 0
    
    infsigmaub <- sigmaub.hat - sigma.b.std.err
    supsigmaub <- sigmaub.hat + sigma.b.std.err
    testsigmaub <- sigmaub.hat - sigma.b.std.err < 0 & sigmaub.hat + sigma.b.std.err > 0
    
    infdif.sigma <- (sigmaua.hat - sigmaub.hat) - sigma.ab.std.err
    supdif.sigma <- (sigmaua.hat - sigmaub.hat) + sigma.ab.std.err
    testdif.sigma <- (sigmaua.hat - sigmaub.hat) - sigma.ab.std.err < 0 & (sigmaua.hat - sigmaub.hat) + sigma.ab.std.err > 0
    
    
    infrhoa <- rhoa.hat - rho.a.std.err
    suprhoa <- rhoa.hat + rho.a.std.err
    testrhoa <- rhoa.hat - rho.a.std.err < 0 & rhoa.hat + rho.a.std.err > 0
    
    infrhob <- rhob.hat - rho.b.std.err
    suprhob <- rhob.hat + rho.b.std.err
    testrhob <- rhob.hat - rho.b.std.err < 0 & rhob.hat + rho.b.std.err > 0
    
    infdif.rho <- (rhoa.hat - rhob.hat) - rho.ab.std.err
    supdif.rho <- (rhoa.hat - rhob.hat) + rho.ab.std.err
    testdif.rho <- (rhoa.hat - rhob.hat) - rho.ab.std.err < 0 & (rhoa.hat - rhob.hat) + rho.ab.std.err > 0
    
    
    return(list(
    sigma.a.std.err, sigma.b.std.err, sigma.ab.std.err, 
    rho.a.std.err, rho.a.std.err, rho.ab.std.err,
    
    beta.std.err,
    infbeta, supbeta, testbeta,
    
    infsigmaua, supsigmaua, testsigmaua,
    infsigmaub, supsigmaub, testsigmaub,
    infdif.sigma, supdif.sigma, testdif.sigma,
    
    infrhoa, suprhoa, testrhoa,
    infrhob, suprhob, testrhob,
    infdif.rho, supdif.rho, testdif.rho))
}

pvalueBeta.2corr <- function(beta0.hat, Fisher) {
    
    z <- abs(beta0.hat) / sqrt(as.vector(diag(Fisher[[5]])))
    p.beta <- pnorm(z, lower.tail=F)
    
    return( 2*p.beta )
}
