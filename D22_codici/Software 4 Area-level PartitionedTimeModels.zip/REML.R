###############################################################################
###
###          Area level Patitioned F-H model with independent time effects
###                             Pagliarella model 1
###
###
### AUTOR: Maria Chiara Pagliarella
### File name: REML.R
### Updated: February 2010
###
### WORKING PROGRESS
###
###############################################################################


REMLarea <- function(X, ydt, D, Da, Db, md, sigma2edt, sigma.0 = sigma.0, MAXITER = 100) {
   
    sigma.fa <- sigma.0
    sigma.fb <- sigma.0
    p <- ncol(X)
    i <- list(1:md[1])
    mdcum <- cumsum(md)
    Db <- D-Da
    
    for(d in 2:D){
        i[[d]] <- (mdcum[d-1]+1):mdcum[d]
        if (d<= Da) ia <- i[1:Da]
        else ib <- i[(Da+1):D]
    }
    
    yda <- Xda <- list()
    for(d in 1:Da) {
        yda[[d]] <- ydt[ia[[d]]]
        Xda[[d]] <- X[ia[[d]],]
    }
    ydb <- Xdb <- list()
    for(d in 1:Db) {
        ydb[[d]] <- ydt[ib[[d]]]
        Xdb[[d]] <- X[ib[[d]],]
    }
    yd <- Xd <- list()
    for(d in 1:D) {
        yd[[d]] <- ydt[i[[d]]]
        Xd[[d]] <- X[i[[d]],]
    }
    
    It<-0
    for(ITER in 1:MAXITER){  
        Vda.inv <- VinvXa <- Vinvya <- list()
        XaV2Xa <- XaV3Xa <- matrix(0, nrow=p, ncol=p)
        tr.Vinva <- tr.V2inva <- XaV2ya <- yaV2ya <- yaV2Xa <- 0
        for(d in 1:Da) {
            ### Elements of the variance matrix
            vda <- (sigma.fa + sigma2edt)[ia[[d]]]
            
            ### Inverse matrix of the variance and submatrices
            Vda.inv[[d]] <- diag(1/vda)
         
            ### Product between V^-1_da and X_da
            ### for all d submatrices
            VinvXa[[d]] <- Vda.inv[[d]] %*% Xda[[d]]
            
            ### Product between V^-1_da  and  y_da
            ### for all d submatrices
            Vinvya[[d]] <- Vda.inv[[d]] %*% yda[[d]]
            
            ### Sum traces of V^-1_da
            tr.Vinva <- tr.Vinva + sum(1/vda)
            
            ### Sum traces of V^-2_da
            tr.V2inva <- tr.V2inva + sum(1/vda^2)
            
            ### Sum on d of the product between  X^t_da, V^-2_da and X_da
            XaV2Xa <- XaV2Xa + t(VinvXa[[d]]) %*% VinvXa[[d]]
            
            ### Sum on d of the product between  X^t_da, V^-3_da and X_da
            XaV3Xa <- XaV3Xa + t(VinvXa[[d]]) %*% Vda.inv[[d]]%*%VinvXa[[d]]
            
            ### Sum on d of the product between  y^t_da, V^-2_da and X_da
            XaV2ya <- XaV2ya + t(VinvXa[[d]]) %*% Vinvya[[d]]
            
            ### Sum on d of the product between  y^t_da, V^-2_da and y_da
            yaV2ya <- yaV2ya + t(Vinvya[[d]]) %*% Vinvya[[d]]
            
            ### Sum on d of the product between  y^t_da, V^-2_da and X_da
            yaV2Xa <- yaV2Xa + t(Vinvya[[d]]) %*% VinvXa[[d]]
        }
        
        
        Vdb.inv <- VinvXb <- Vinvyb <- list()
        XbV2Xb <- XbV3Xb <- matrix(0, nrow=p, ncol=p)
        tr.Vinvb <- tr.V2invb <- XbV2yb <- ybV2yb <- ybV2Xb <- 0
        for(d in 1:Db) {
            ### Elements of the variance matrix
            vdb <- (sigma.fb + sigma2edt)[ib[[d]]]
            
            ### Inverse matrix of the variance and submatrices
            Vdb.inv[[d]] <- diag(1/vdb)
            
            ### Product between V^-1_db and X_db
            ### for all d submatrices
            VinvXb[[d]] <- Vdb.inv[[d]] %*% Xdb[[d]]
            
            ### Product between V^-1_db  and  y_db
            ### for all d submatrices
            Vinvyb[[d]] <- Vdb.inv[[d]] %*% ydb[[d]]
            
            ### Sum traces of V^-1_db
            tr.Vinvb <- tr.Vinvb + sum(1/vdb)
            
            ### Sum traces of V^-2_db
            tr.V2invb <- tr.V2invb + sum(1/vdb^2)
            
            ### Sum on d of the product between  X^t_db, V^-2_db and X_db
            XbV2Xb <- XbV2Xb + t(VinvXb[[d]]) %*% VinvXb[[d]]
            
            ### Sum on d of the product between  X^t_db, V^-3_db and X_db
            XbV3Xb <- XbV3Xb + t(VinvXb[[d]]) %*% Vdb.inv[[d]]%*%VinvXb[[d]]
            
            ### Sum on d of the product between  y^t_db, V^-2_db and X_db
            XbV2yb <- XbV2yb + t(VinvXb[[d]]) %*% Vinvyb[[d]]
            
            ### Sum on d of the product between  y^t_db, V^-2_db and y_db
            ybV2yb <- ybV2yb + t(Vinvyb[[d]]) %*% Vinvyb[[d]]
            
            ### Sum on d of the product between  y^t_db, V^-2_db and X_db
            ybV2Xb <- ybV2Xb + t(Vinvyb[[d]]) %*% VinvXb[[d]]
        }        

        

        Vd.inv <- Vinvy <- VinvX <- list()
        Q.inv <- matrix(0, nrow=p, ncol=p)  
        yVX <- 0
            for(d in 1:D) {
            ### Elements of the variance matrix
            if (d <= Da)
                vd <-(sigma.fa + sigma2edt)[ia[[d]]]
            else
                vd <-(sigma.fb + sigma2edt)[i[[d]]]
            
            ### Inverse matrix of the variance and submatrices
            Vd.inv[[d]] <- diag(1/vd)
            
            ### Product between V^-1_ed  and  y_d
            ### for all d submatrices
            Vinvy[[d]] <- Vd.inv[[d]] %*% yd[[d]]
                       
            ### Product between V^-1_ed  and  X_d
            ### for all d submatrices
            VinvX[[d]] <- Vd.inv[[d]] %*% Xd[[d]]
            
            ### Inverse of Q. Next we calculate Q
            Q.inv <- Q.inv + t(Xd[[d]]) %*% VinvX[[d]]
            
            ### Sum on d of the product between  y^t_d, V^-1_d and X_d
            yVX <- yVX + yd[[d]] %*% VinvX[[d]]
        }
        
        Q <- solve(Q.inv)
        
        
        tr.XaV2XaQ <- 0
        tr.XaV2XaQ <- tr.XaV2XaQ + sum(diag( XaV2Xa %*% Q ))
       
        tr.PV1 <- tr.Vinva - tr.XaV2XaQ
        tr.PV1PV1 <- tr.V2inva - 2*sum(diag(XaV3Xa %*% Q)) + sum(diag(XaV2Xa %*% Q %*% XaV2Xa %*% Q))
        yPV1Py <- yaV2ya - ( yaV2Xa %*% Q %*% t(yVX)) - ( yVX %*% Q %*% XaV2ya ) + ( yVX %*% Q %*% XaV2Xa %*% Q %*% t(yVX))
        
                        
        tr.XbV2XbQ <- 0
        tr.XbV2XbQ <- tr.XbV2XbQ + sum(diag( XbV2Xb %*% Q ))
        
        tr.PV2 <- tr.Vinvb - tr.XbV2XbQ
        tr.PV2PV2 <- tr.V2invb - 2*sum(diag(XbV3Xb %*% Q)) + sum(diag(XbV2Xb %*% Q %*% XbV2Xb %*% Q))
        yPV2Py <- ybV2yb - ( ybV2Xb %*% Q %*% t(yVX)) - ( yVX %*% Q %*% XbV2yb ) + ( yVX %*% Q %*% XbV2Xb %*% Q %*% t(yVX))
        
        tr.PV1PV2<-0
        tr.PV2PV1<-0
        
        ### Scores and Fisher information matrix
        S1 <- -0.5*tr.PV1 + 0.5*yPV1Py
        S2 <- -0.5*tr.PV2 + 0.5*yPV2Py
        
        F11 <- 0.5*tr.PV1PV1
        F12 <- 0.5*tr.PV1PV2
        F21 <- 0.5*tr.PV2PV1
        F22 <- 0.5*tr.PV2PV2
        
        F <- matrix(c(F11, F12, F21, F22), ncol=2, nrow=2)
        
        ### Fisher-Scoring Algorithm
        difa <- S1/F11
        difb <- S2/F22
        
        sigma.fa <- sigma.fa + difa
        sigma.fb <- sigma.fb + difb
        
        It<-ITER
        
        ### Stopping criterion
        if((abs(difa)<0.000001) && (abs(difb)<0.000001)) break
        
        #x<-"ITER maggiore di 6"
        #z<-"ITER minore di 6"
        #if (ITER>6) print(x) else print(z)
        
    }
    return(list(as.vector(sigma.fa), as.vector(sigma.fb), F, It, Q))
}
