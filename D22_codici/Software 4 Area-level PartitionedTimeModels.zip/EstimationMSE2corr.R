###############################################################################
###
###          Area level Partitioned F-H model with correlated time effects
###                             Pagliarella model 3
###
###
### AUTOR: AUTOR: Maria Chiara Pagliarella
### File name: EstimationMSE2corr.R
### Updated: May 2010
###
###
###############################################################################


mse.area.2corr <- function(X, D, Da, Db, md, mda, mdb, sigma2edt, sigmaua, sigmaub, rhoa, rhob, F11, F22, F12, F33, F44, F34) {

    sigmaua <- sigmaua.hat
    sigmaub <- sigmaub.hat
    rhoa <- rhoa.hat
    rhob <- rhob.hat
    
    p <- ncol(X)
    i <- list(1:md[1])
    mdcum <- cumsum(md)
    Db <- D-Da
    
    for(d in 2:D){
        i[[d]] <- (mdcum[d-1]+1):mdcum[d]
        if (d<= Da) ia <- i[1:Da]
        else ib <- i[(Da+1):D]
    }
    

    Xda <- list()
    for(d in 1:Da) {
        Xda[[d]] <- X[ia[[d]],]
    }
    Xdb <- list()
    for(d in 1:Db) {
        Xdb[[d]] <- X[ib[[d]],]
    }
    Xd <- list()
    for(d in 1:D) {
        Xd[[d]] <- X[i[[d]],]
    }
    
    
    ########################################################
    ###       Calculation of elements of g1, g2 and g3 FOR A
        
    Omega.a <- OmegaFirst.a <- Vda.inv <- VinvOmega.a <- VinvOmegaFirst.a <- OmegaVinvOmega.a <- OmegaVinvOmegaFirst.a <- OmegaFirstVinvOmegaFirst.a <-
    g1.a <- Sinv.a <- SinvXda <- OmegaVinvOmegaSinvXda <- g2.1a <- q11 <- q12 <- q22 <- list()
    for(d in 1:Da) {
        
        ### Elements of the variance matrix
        Omega.a[[d]] <- matrix(0,nrow=mda[d],ncol=mda[d])
        Omega.a[[d]][lower.tri(Omega.a[[d]])] <- rhoa^sequence((mda[d]-1):1)
        Omega.a[[d]] <- Omega.a[[d]] + t(Omega.a[[d]])
        diag(Omega.a[[d]]) <- 1
        Omega.a[[d]] <- (1/(1-rhoa^2)) * Omega.a[[d]]
        
        vda <-(sigmaua * Omega.a[[d]] + diag(sigma2edt[ia[[d]]]))
        
        OmegaFirst.a[[d]] <- matrix(0,nrow=mda[d],ncol=mda[d])
        OmegaFirst.a[[d]][lower.tri(OmegaFirst.a[[d]])] <- sequence((mda[d]-1):1)*rhoa^(sequence((mda[d]-1):1)-1)
        OmegaFirst.a[[d]] <- OmegaFirst.a[[d]] + t(OmegaFirst.a[[d]])
        OmegaFirst.a[[d]] <- (1/(1-rhoa^2)) * OmegaFirst.a[[d]]
        OmegaFirst.a[[d]] <- OmegaFirst.a[[d]] + (2*rhoa / (1-rhoa^2)) * Omega.a[[d]]
        
        ### Inverse matrix of the variance and submatrices
        Vda.inv[[d]] <- solve(vda)
        
        VinvOmega.a[[d]] <- Vda.inv[[d]] %*% Omega.a[[d]]                  ### Product between V^-1_da and Omega_a
        VinvOmegaFirst.a[[d]] <- Vda.inv[[d]] %*% OmegaFirst.a[[d]]        ### Product between V^-1_da and OmegaFirst_a
        OmegaVinvOmega.a[[d]] <- t(VinvOmega.a[[d]]) %*% Omega.a[[d]]       ### Product between Omega.a, V^-1_da and Omega.a
        OmegaVinvOmegaFirst.a[[d]] <- Omega.a[[d]] %*% Vda.inv[[d]] %*% OmegaFirst.a [[d]]   ### Product of Omega_a with V^-1_da and OmegaFirst_a
        OmegaFirstVinvOmegaFirst.a[[d]] <- OmegaFirst.a[[d]] %*% Vda.inv[[d]] %*% OmegaFirst.a[[d]]   ### Product of OmegaFirst_a with V^-1_da and OmegaFirst_a
        
        
        g1.a[[d]] <- (sigmaua * Omega.a[[d]]) - ((sigmaua)^2 * OmegaVinvOmega.a[[d]])     ### Calculation of g1_a
        
        sed.a <- sigma2edt[ia[[d]]]                               ### Elements of the variance matrix Sigma_ed_a
        Sinv.a[[d]] <- diag(1/sed.a)                            ### Inverse matrix of Sigma_ed for all d submatrices_a
        SinvXda[[d]] <- Sinv.a[[d]] %*% Xda[[d]]                ### Product between Sigma_a^-1_ed and X_da for all d submatrices_a
        OmegaVinvOmegaSinvXda[[d]] <- OmegaVinvOmega.a[[d]] %*% SinvXda[[d]]   # Product Omega.a with V^-1_da  for Omega.a and Sigma^-1_ed  for  X_da for all submatrices
        
        ### First part of g2_a (the second is its transpose)
        g2.1a[[d]] <- Xda[[d]] - sigmaua * Omega.a[[d]] %*% SinvXda[[d]] + (sigmaua^2) * OmegaVinvOmegaSinvXda[[d]]
        
        ### Elements q11, q22 and q12 for calcultion of g3_a
        q11[[d]] <- OmegaVinvOmega.a[[d]] - 2 * sigmaua * OmegaVinvOmega.a[[d]] %*% VinvOmega.a[[d]] + 
                    (sigmaua)^2 * OmegaVinvOmega.a[[d]] %*% Vda.inv[[d]] %*% OmegaVinvOmega.a[[d]]
        q12[[d]] <- sigmaua * OmegaVinvOmegaFirst.a[[d]] - (sigmaua)^2 * OmegaVinvOmegaFirst.a[[d]] %*% VinvOmega.a[[d]] - 
                    (sigmaua)^2 * OmegaVinvOmega.a[[d]] %*% VinvOmegaFirst.a[[d]] + (sigmaua)^3 * OmegaVinvOmega.a[[d]] %*% VinvOmegaFirst.a[[d]] %*% VinvOmega.a[[d]]
        q22[[d]] <- (sigmaua)^2 * OmegaFirstVinvOmegaFirst.a[[d]] - 2 * (sigmaua)^3 * OmegaVinvOmegaFirst.a[[d]] %*% VinvOmegaFirst.a[[d]] +
                    (sigmaua)^4 * OmegaVinvOmegaFirst.a[[d]] %*% Vda.inv[[d]] %*% t(OmegaVinvOmegaFirst.a[[d]])
    }
    
    
    ########################################################
    ###       Calculation of elements of g1, g2 and g3 FOR B
    
    
    Omega.b <- OmegaFirst.b <- Vdb.inv <- VinvOmega.b <- VinvOmegaFirst.b <- OmegaVinvOmega.b <- OmegaVinvOmegaFirst.b <- OmegaFirstVinvOmegaFirst.b <-
    g1.b <- Sinv.b <- SinvXdb <- OmegaVinvOmegaSinvXdb <- g2.1b <- q33 <- q34 <- q44 <- list()
    for(d in 1:Db) {
        
        ### Elements of the variance matrix
        Omega.b[[d]] <- matrix(0,nrow=mdb[d],ncol=mdb[d])
        Omega.b[[d]][lower.tri(Omega.b[[d]])] <- rhob^sequence((mdb[d]-1):1)
        Omega.b[[d]] <- Omega.b[[d]] + t(Omega.b[[d]])
        diag(Omega.b[[d]]) <- 1
        Omega.b[[d]] <- (1/(1-rhob^2)) * Omega.b[[d]]
        
        vdb <-(sigmaub * Omega.b[[d]] + diag(sigma2edt[ib[[d]]]))
        
        OmegaFirst.b[[d]] <- matrix(0,nrow=mdb[d],ncol=mdb[d])
        OmegaFirst.b[[d]][lower.tri(OmegaFirst.b[[d]])] <- sequence((mdb[d]-1):1)*rhob^(sequence((mdb[d]-1):1)-1)
        OmegaFirst.b[[d]] <- OmegaFirst.b[[d]] + t(OmegaFirst.b[[d]])
        OmegaFirst.b[[d]] <- (1/(1-rhob^2)) * OmegaFirst.b[[d]]
        OmegaFirst.b[[d]] <- OmegaFirst.b[[d]] + (2*rhob / (1-rhob^2)) * Omega.b[[d]]
        
        
        ### Inverse matrix of the variance and submatrices
        Vdb.inv[[d]] <- solve(vdb)
        
        VinvOmega.b[[d]] <- Vdb.inv[[d]] %*% Omega.b[[d]]                  ### Product between V^-1_db and Omega_b
        VinvOmegaFirst.b[[d]] <- Vdb.inv[[d]] %*% OmegaFirst.b[[d]]        ### Product between V^-1_db and OmegaFirst_b
        OmegaVinvOmega.b[[d]] <- t(VinvOmega.b[[d]]) %*% Omega.b[[d]]         ### Product between Omega.b, V^-1_db and Omega.b
        OmegaVinvOmegaFirst.b[[d]] <- Omega.b[[d]] %*% Vdb.inv[[d]] %*% OmegaFirst.b [[d]]   ### Product of Omega_b with V^-1_db and OmegaFirst_b
        OmegaFirstVinvOmegaFirst.b[[d]] <- OmegaFirst.b[[d]] %*% Vdb.inv[[d]] %*% OmegaFirst.b[[d]]   ### Product of OmegaFirst_b with V^-1_db and OmegaFirst_b
         
        
        g1.b[[d]] <- (sigmaub * Omega.b[[d]]) - ((sigmaub)^2 * OmegaVinvOmega.b[[d]])     ### Calculation of g1_b
        
        sed.b <- diag(sigma2edt[ib[[d]]])                      ### Elements of the variance matrix Sigma_ed_b
        Sinv.b[[d]] <- solve(sed.b)                            ### Inverse matrix of Sigma_ed for all d submatrices_b
        SinvXdb[[d]] <- Sinv.b[[d]] %*% Xdb[[d]]                ### Product between Sigma_b^-1_ed and X_db for all d submatrices_b
        OmegaVinvOmegaSinvXdb[[d]] <- OmegaVinvOmega.b[[d]] %*% SinvXdb[[d]]   # Product Omega.b with V^-1_db  for Omega.b and Sigma^-1_ed  for X_db for all submatrices
        
        ### First part of g2_b (the second is its transpose)
        g2.1b[[d]] <- Xdb[[d]] - sigmaub * Omega.b[[d]] %*% SinvXdb[[d]] + (sigmaub^2) * OmegaVinvOmegaSinvXdb[[d]]
        
        ### Elements q33, q44 and q34 for calcultion of g3_b
        q33[[d]] <- OmegaVinvOmega.b[[d]] - 2 * sigmaub * OmegaVinvOmega.b[[d]] %*% VinvOmega.b[[d]] + 
                    (sigmaub)^2 * OmegaVinvOmega.b[[d]] %*% Vdb.inv[[d]] %*% OmegaVinvOmega.b[[d]]
        q34[[d]] <- sigmaub * OmegaVinvOmegaFirst.b[[d]] - (sigmaub)^2 * OmegaVinvOmegaFirst.b[[d]] %*% VinvOmega.b[[d]] - 
                    (sigmaub)^2 * OmegaVinvOmega.b[[d]] %*% VinvOmegaFirst.b[[d]] + (sigmaub)^3 * OmegaVinvOmega.b[[d]] %*% VinvOmegaFirst.b[[d]] %*% VinvOmega.b[[d]]
        q44[[d]] <- (sigmaub)^2 * OmegaFirstVinvOmegaFirst.b[[d]] - 2 * (sigmaub)^3 * OmegaVinvOmegaFirst.b[[d]] %*% VinvOmegaFirst.b[[d]] +
                    (sigmaub)^4 * OmegaVinvOmegaFirst.b[[d]] %*% Vdb.inv[[d]] %*% t(OmegaVinvOmegaFirst.b[[d]])
    }
    
    
    ### Calculation of Q
    
    Vd.inv <- VinvX <- list()
    Q.inv <- matrix(0, nrow=p, ncol=p)
    
    for(d in 1:D) {
        
        ### Elements of the variance matrix TOTAL (A & B)
        if (d <= Da) {
            Omega.a <- matrix(0,nrow=mda[d],ncol=mda[d])
            Omega.a[lower.tri(Omega.a)] <- rhoa^sequence((mda[d]-1):1)
            Omega.a <- Omega.a + t(Omega.a)
            diag(Omega.a) <- 1
            Omega.a <- (1/(1-rhoa^2)) * Omega.a
            vd <-(sigmaua * Omega.a + diag(sigma2edt[ia[[d]]]))}
        else {
            Omega.b <- matrix(0,nrow=md[d],ncol=md[d])
            Omega.b[lower.tri(Omega.b)] <- rhob^sequence((md[d]-1):1)
            Omega.b <- Omega.b + t(Omega.b)
            diag(Omega.b) <- 1
            Omega.b <- (1/(1-rhob^2)) * Omega.b
            vd <-(sigmaub * Omega.b + diag(sigma2edt[i[[d]]]))}
        
        ### Inverse matrix of the variance and submatrices
        Vd.inv[[d]] <- solve(vd)
        
        ### Inverse of Q. Next we calculate Q
        Q.inv <- Q.inv + t(Xd[[d]]) %*% Vd.inv[[d]] %*% Xd[[d]]
    }
    
    Q <- solve(Q.inv)
    
    
    ### Calculation of MSE_A
    
    Fsig.a <- matrix(c(F11, F12, F12, F22),ncol=2)
    g1a <- g2a <- g3a <- list()
    for(d in 1:Da){
        g1a[[d]] <- diag(g1.a[[d]])
        g2a[[d]] <- diag(g2.1a[[d]] %*% Q %*% t(g2.1a[[d]]))
        q11[[d]] <- diag(q11[[d]])
        q12[[d]] <- diag(q12[[d]])
        q22[[d]] <- diag(q22[[d]])
    }
    for(d in 1:Da){
    g3a[[d]] <- vector()
        for(i in 1:mda[d]){
            g3a[[d]][i] <- sum(diag(matrix(c(q11[[d]][i],rep(q12[[d]][i],2),q22[[d]][i]),nrow=2) %*% solve(Fsig.a)))
        }
    }
    
    
    
    ### Calculation of MSE_B
    
    Fsig.b <- matrix(c(F33, F34, F34, F44),ncol=2)
    g1b <- g2b <- g3b <- list()
    for(d in 1:Db){
        g1b[[d]] <- diag(g1.b[[d]])
        g2b[[d]] <- diag(g2.1b[[d]] %*% Q %*% t(g2.1b[[d]]))
        q33[[d]] <- diag(q33[[d]])
        q34[[d]] <- diag(q34[[d]])
        q44[[d]] <- diag(q44[[d]])
    }
    for(d in 1:Db){
    g3b[[d]] <- vector()
        for(i in 1:mdb[d]){
            g3b[[d]][i] <- sum(diag(matrix(c(q33[[d]][i],rep(q34[[d]][i],2),q44[[d]][i]),nrow=2) %*% solve(Fsig.b)))
        }
    }
    
    
    g1a <- unlist(g1a)
    g1b <- unlist(g1b)
    g2a <- unlist(g2a)
    g2b <- unlist(g2b)
    g3a <- unlist(g3a)
    g3b <- unlist(g3b)
    
    ### Calculation of MSE
    
    mse.a <- g1a + g2a + 2 * g3a
    mse.b <- g1b + g2b + 2 * g3b
    mse <- c(mse.a, mse.b)
    
    return(mse)
}
