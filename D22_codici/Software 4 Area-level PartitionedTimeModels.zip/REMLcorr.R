###############################################################################
###
###          Area level Partitioned F-H model with correlated time effects
###                             Pagliarella model 2
###
###
### AUTOR: AUTOR: Maria Chiara Pagliarella
### File name: REMLcorr.R
### Updated: July 2010
###
###
###############################################################################

REMLarea.corr <- function(X, ydt, D, Da, Db, md, mda, mdb, sigma2edt, sigma.fa, sigma.fb, rho, MAXITER = 100) {
    
    theta.f  <- as.vector(c(sigma.fa, sigma.fb, rho))
    
    p <- ncol(X)
    i <- list(1:md[1])
    mdcum <- cumsum(md)
    Db <- D-Da
        
    for(d in 2:D){
        i[[d]] <- (mdcum[d-1]+1):mdcum[d]
        if (d<= Da) ia <- i[1:Da]
        else ib <- i[(Da+1):D]
    }
    
    yda <- Xda <- list()
    for(d in 1:Da) {
        yda[[d]] <- ydt[ia[[d]]]
        Xda[[d]] <- X[ia[[d]],]
    }
    ydb <- Xdb <- list()
    for(d in 1:Db) {
        ydb[[d]] <- ydt[ib[[d]]]
        Xdb[[d]] <- X[ib[[d]],]
    }
    yd <- Xd <- list()
    for(d in 1:D) {
        yd[[d]] <- ydt[i[[d]]]
        Xd[[d]] <- X[i[[d]],]
    }
    
    Bad <- Flag <- 0
    
    for(ITER in 1:MAXITER) {
               
        V1 <- Vda.inv <- VinvXa <- Vinvya <- VinvV1 <- XVinvV1VinvX <- VinvV1VinvV1 <- XVinvV1VinvV1VinvX <- list()
        tr.VinvV1 <- yVinvXa <- yVinvV1Vinvy <- yVinvV1VinvX <- SumXVinvV1VinvX <- tr.VinvV1VinvV1 <- 0
        
        V3.a <- VinvV1VinvV3.a <- XVinvV1VinvV3VinvX.a <- list()
        tr.VinvV1VinvV3.a <- 0
        
        for(d in 1:Da) {
            
            ### Matrix Omega and its derivatives ------------- A
            Omega.a <- matrix(0,nrow=mda[d],ncol=mda[d])
            Omega.a[lower.tri(Omega.a)] <- rho^sequence((mda[d]-1):1)
            Omega.a <- Omega.a + t(Omega.a)
            diag(Omega.a) <- 1
            Omega.a <- (1/(1-rho^2)) * Omega.a
            V1[[d]] <- Omega.a
            
            #print(V1)
            
            OmegaFirst.a <- matrix(0,nrow=mda[d],ncol=mda[d])
            OmegaFirst.a[lower.tri(OmegaFirst.a)] <- sequence((mda[d]-1):1)*rho^(sequence((mda[d]-1):1)-1)
            OmegaFirst.a <- OmegaFirst.a + t(OmegaFirst.a)
            OmegaFirst.a <- (1/(1-rho^2)) * OmegaFirst.a
            OmegaFirst.a <- OmegaFirst.a + (2*rho / (1-rho^2)) * Omega.a
            V3.a[[d]] <- sigma.fa * OmegaFirst.a
            
            ### Elements of the variance matrix
            Vda <- (sigma.fa * Omega.a + diag(sigma2edt[ia[[d]]]))
            
            if (abs(det(Vda))<0.000000001 || abs(det(Vda))>10000000000) {
                Flag <- 1
                Bad <- Bad+1
                print("Bad Vda")
                break }
            
            
            ### Inverse of variance matrix
            Vda.inv[[d]] <- solve(Vda)
            
            ### Product between V^-1_da and X_da
            ### for all d submatrices
            VinvXa[[d]] <- Vda.inv[[d]] %*% Xda[[d]]
            
            ### Product between V^-1_da  and  y_da
            ### for all d submatrices
            Vinvya[[d]] <- Vda.inv[[d]] %*% yda[[d]]
            
            
            # calculation of the elements function of V1
            # derivatives of V with respect to sigma^2_A
            
            # S1
            
            VinvV1[[d]] <- Vda.inv[[d]] %*% V1[[d]]
            tr.VinvV1 <- tr.VinvV1 + sum(diag(VinvV1[[d]]))
            
            XVinvV1VinvX[[d]] <- t(VinvXa[[d]]) %*% V1[[d]] %*% VinvXa[[d]]
            SumXVinvV1VinvX <- SumXVinvV1VinvX + XVinvV1VinvX[[d]]
            
            yVinvXa <- yVinvXa + t(yda[[d]]) %*% VinvXa[[d]]
            yVinvV1Vinvy <- yVinvV1Vinvy + t(Vinvya[[d]]) %*% V1[[d]] %*% Vinvya[[d]]
            yVinvV1VinvX <- yVinvV1VinvX + t(Vinvya[[d]]) %*% V1[[d]] %*% VinvXa[[d]]
            
            
            # F11
            
            VinvV1VinvV1[[d]] <- Vda.inv[[d]] %*% V1[[d]] %*% Vda.inv[[d]] %*% V1[[d]]
            tr.VinvV1VinvV1 <- tr.VinvV1VinvV1 + sum(diag(VinvV1VinvV1[[d]]))
            
            XVinvV1VinvV1VinvX[[d]] <- t(VinvXa[[d]]) %*% V1[[d]] %*% Vda.inv[[d]] %*% V1[[d]] %*% VinvXa[[d]]    
            
            # calculation of the elements function of V3_A
            # derivatives of V_a with respect to rho
            
            # F13.a
            
            VinvV1VinvV3.a[[d]] <- Vda.inv[[d]] %*% V1[[d]] %*% Vda.inv[[d]] %*% V3.a[[d]]
            tr.VinvV1VinvV3.a <- tr.VinvV1VinvV3.a + sum(diag(VinvV1VinvV3.a[[d]]))
            
            XVinvV1VinvV3VinvX.a[[d]] <- t(VinvXa[[d]]) %*% V1[[d]] %*% Vda.inv[[d]] %*% V3.a[[d]] %*% VinvXa[[d]]
            
        }

        if (Flag==1) {
            ITER <- MAXITER
            Flag <- 0
            break }
        
        
        V2 <- Vdb.inv <- VinvXb <- Vinvyb <- VinvV2 <- XVinvV2VinvX <- VinvV2VinvV2 <- XVinvV2VinvV2VinvX <- list()
        tr.VinvV2 <- yVinvXb <- yVinvV2Vinvy <- yVinvV2VinvX <- SumXVinvV2VinvX <- tr.VinvV2VinvV2 <- 0
        
        V3.b <- VinvV2VinvV3.b <- XVinvV2VinvV3VinvX.b <- list()
        tr.VinvV2VinvV3.b <- 0
        
        for(d in 1:Db) {
            
            ### Matrix Omega and its derivatives ------------- B
            Omega.b <- matrix(0,nrow=mdb[d],ncol=mdb[d])
            Omega.b[lower.tri(Omega.b)] <- rho^sequence((mdb[d]-1):1)
            Omega.b <- Omega.b + t(Omega.b)
            diag(Omega.b) <- 1
            Omega.b <- (1/(1-rho^2)) * Omega.b
            V2[[d]] <- Omega.b
            
            OmegaFirst.b <- matrix(0,nrow=mdb[d],ncol=mdb[d])
            OmegaFirst.b[lower.tri(OmegaFirst.b)] <- sequence((mdb[d]-1):1)*rho^(sequence((mdb[d]-1):1)-1)
            OmegaFirst.b <- OmegaFirst.b + t(OmegaFirst.b)
            OmegaFirst.b <- (1/(1-rho^2)) * OmegaFirst.b
            OmegaFirst.b <- OmegaFirst.b + (2*rho / (1-rho^2)) * Omega.b
            V3.b[[d]] <- sigma.fb * OmegaFirst.b
            
            ### Elements of the variance matrix
            Vdb <- (sigma.fb * Omega.b + diag(sigma2edt[ib[[d]]]))
            
            #print(Vdb)
            #print(sigma2edt[ib[[d]]])
            #print(sigma.fb)
            #print(Omega.b)
            
            if (abs(det(Vdb))<0.000000001 || abs(det(Vdb))>10000000000) {
                Flag <- 1
                Bad <- Bad + 1
                print("Bad Vdb")
                break }
            
            ### Inverse of variance matrix
            Vdb.inv[[d]] <- solve(Vdb)
            
            ### Product between V^-1_db and X_db
            ### for all d submatrices
            VinvXb[[d]] <- Vdb.inv[[d]] %*% Xdb[[d]]
            
            ### Product between V^-1_db  and  y_db
            ### for all d submatrices
            Vinvyb[[d]] <- Vdb.inv[[d]] %*% ydb[[d]]
            
            # calculation of the elements function of V2
            # derivatives of V with respect to sigma^2_B
            
            # S2
            
            VinvV2[[d]] <- Vdb.inv[[d]] %*% V2[[d]]
            tr.VinvV2 <- tr.VinvV2 + sum(diag(VinvV2[[d]]))
            
            XVinvV2VinvX[[d]] <- t(VinvXb[[d]]) %*% V2[[d]] %*% VinvXb[[d]]
            SumXVinvV2VinvX <- SumXVinvV2VinvX + XVinvV2VinvX[[d]]
            
            yVinvXb <- yVinvXb + t(ydb[[d]]) %*% VinvXb[[d]]
            yVinvV2Vinvy <- yVinvV2Vinvy + t(Vinvyb[[d]]) %*% V2[[d]] %*% Vinvyb[[d]]
            yVinvV2VinvX <- yVinvV2VinvX + t(Vinvyb[[d]]) %*% V2[[d]] %*% VinvXb[[d]]
            
            # F22
            
            VinvV2VinvV2[[d]] <- Vdb.inv[[d]] %*% V2[[d]] %*% Vdb.inv[[d]] %*% V2[[d]]
            tr.VinvV2VinvV2 <- tr.VinvV2VinvV2 + sum(diag(VinvV2VinvV2[[d]]))
            
            XVinvV2VinvV2VinvX[[d]] <- t(VinvXb[[d]]) %*% V2[[d]] %*% Vdb.inv[[d]] %*% V2[[d]] %*% VinvXb[[d]]
            
            # calculation of the elements function of V3_B
            # derivatives of V_B with respect to rho
            
            # F23.b
            
            VinvV2VinvV3.b[[d]] <- Vdb.inv[[d]] %*% V2[[d]] %*% Vdb.inv[[d]] %*% V3.b[[d]]
            tr.VinvV2VinvV3.b <- tr.VinvV2VinvV3.b + sum(diag(VinvV2VinvV3.b[[d]]))
            
            XVinvV2VinvV3VinvX.b[[d]] <- t(VinvXb[[d]]) %*% V2[[d]] %*% Vdb.inv[[d]] %*% V3.b[[d]] %*% VinvXb[[d]]    
            
        }
        
        if (Flag==1) {
            ITER <- MAXITER
            Flag <- 0
            break }
        
        
        V3 <- Vd.inv <- VinvX <- Vinvy <- VinvV3 <- XVinvV3VinvX <- VinvV3VinvV3 <- XVinvV3VinvV3VinvX <- list()
        tr.VinvV3 <- SumXVinvV3VinvX <- yVinvX <- yVinvV3Vinvy <- yVinvV3VinvX <- tr.VinvV3VinvV3 <- 0
        Q.inv <- matrix(0, nrow=p, ncol=p)
        for(d in 1:D) {
            
            if (d <= Da){
                ### Matrix Omega and its derivatives ------------- A
                OmegaFirst.a <- matrix(0,nrow=mda[d],ncol=mda[d])
                OmegaFirst.a[lower.tri(OmegaFirst.a)] <- sequence((mda[d]-1):1)*rho^(sequence((mda[d]-1):1)-1)
                OmegaFirst.a <- OmegaFirst.a + t(OmegaFirst.a)
                OmegaFirst.a <- (1/(1-rho^2)) * OmegaFirst.a
                OmegaFirst.a <- OmegaFirst.a + (2*rho / (1-rho^2)) * Omega.a
                V3[[d]] <- sigma.fa * OmegaFirst.a}
            else{
                ### Matrix Omega and its derivatives ------------- B
                OmegaFirst.b <- matrix(0,nrow=md[d],ncol=md[d])
                OmegaFirst.b[lower.tri(OmegaFirst.b)] <- sequence((md[d]-1):1)*rho^(sequence((md[d]-1):1)-1)
                OmegaFirst.b <- OmegaFirst.b + t(OmegaFirst.b)
                OmegaFirst.b <- (1/(1-rho^2)) * OmegaFirst.b
                OmegaFirst.b <- OmegaFirst.b + (2*rho / (1-rho^2)) * Omega.b
                V3[[d]] <- sigma.fb * OmegaFirst.b}
            
            if (d <= Da)
                vd <-(sigma.fa * Omega.a + diag(sigma2edt[ia[[d]]]))
            else
                vd <-(sigma.fb * Omega.b + diag(sigma2edt[i[[d]]]))
            #print(V3)
            if  (abs(det(vd))<0.000000001 || abs(det(vd))>10000000000) {
                Flag <- 1
                Bad <- Bad + 1
                print("Bad vd")
                break }
            
            ### Inverse matrix of the variance and submatrices
            Vd.inv[[d]] <- solve(vd)
            
            
            ### Product between V^-1_d and X_d
            ### for all d submatrices
            VinvX[[d]] <- Vd.inv[[d]] %*% Xd[[d]]
            
            ### Product between V^-1_d and  y_d
            ### for all d submatrices
            Vinvy[[d]] <- Vd.inv[[d]] %*% yd[[d]]
                   
            ### Inverse of Q. Next we calculate Q
            Q.inv <- Q.inv + t(Xd[[d]]) %*% VinvX[[d]]
            
            
            # calculation of the elements function of V3
            # derivatives of V (total) with respect to rho
            
            # S3
            
            VinvV3[[d]] <- Vd.inv[[d]] %*% V3[[d]]
            tr.VinvV3 <- tr.VinvV3 + sum(diag(VinvV3[[d]]))
            
            XVinvV3VinvX[[d]] <- t(VinvX[[d]]) %*% V3[[d]] %*% VinvX[[d]]
            SumXVinvV3VinvX <- SumXVinvV3VinvX + XVinvV3VinvX[[d]]
            
            yVinvX <- yVinvX + t(yd[[d]]) %*% VinvX[[d]]
            yVinvV3Vinvy <- yVinvV3Vinvy + t(Vinvy[[d]]) %*% V3[[d]] %*% Vinvy[[d]]
            yVinvV3VinvX <- yVinvV3VinvX + t(Vinvy[[d]]) %*% V3[[d]] %*% VinvX[[d]]
            
            # F33
            
            VinvV3VinvV3[[d]] <- Vd.inv[[d]] %*% V3[[d]] %*% Vd.inv[[d]] %*% V3[[d]]
            tr.VinvV3VinvV3 <- tr.VinvV3VinvV3 + sum(diag(VinvV3VinvV3[[d]]))
            
            XVinvV3VinvV3VinvX[[d]] <- t(VinvX[[d]]) %*% V3[[d]] %*% Vd.inv[[d]] %*% V3[[d]] %*% VinvX[[d]]    
            
        }
        
        if (Flag==1) {
            ITER <- MAXITER
            Flag <- 0
            break }
        
        ### Calculation of Q
        Q <- solve(Q.inv)
        
        
        tr.XVinvV1VinvXQ <- tr.XVinvV1VinvV1VinvXQ <- XVinvV1VinvXQ <- tr.XVinvV1VinvV3VinvX.aQ <- 0
        for(d in 1:Da){
        tr.XVinvV1VinvXQ <- tr.XVinvV1VinvXQ + sum(diag(XVinvV1VinvX[[d]] %*% Q))
        tr.XVinvV1VinvV1VinvXQ <- tr.XVinvV1VinvV1VinvXQ  + sum(diag(XVinvV1VinvV1VinvX[[d]] %*% Q))
        XVinvV1VinvXQ <- XVinvV1VinvXQ + XVinvV1VinvX[[d]] %*% Q
        tr.XVinvV1VinvV3VinvX.aQ <- tr.XVinvV1VinvV3VinvX.aQ + sum(diag(XVinvV1VinvV3VinvX.a[[d]] %*% Q))
        }
        
        tr.XVinvV2VinvXQ <- tr.XVinvV2VinvV2VinvXQ <- XVinvV2VinvXQ <- tr.XVinvV2VinvV3VinvX.bQ <- 0
        for(d in 1:Db){
        tr.XVinvV2VinvXQ <- tr.XVinvV2VinvXQ + sum(diag(XVinvV2VinvX[[d]] %*% Q))
        tr.XVinvV2VinvV2VinvXQ <- tr.XVinvV2VinvV2VinvXQ  + sum(diag(XVinvV2VinvV2VinvX[[d]] %*% Q))
        XVinvV2VinvXQ <- XVinvV2VinvXQ + XVinvV2VinvX[[d]] %*% Q
        tr.XVinvV2VinvV3VinvX.bQ <- tr.XVinvV2VinvV3VinvX.bQ + sum(diag(XVinvV2VinvV3VinvX.b[[d]] %*% Q))
        }
        
        tr.XVinvV3VinvXQ <- tr.XVinvV3VinvV3VinvXQ <- XVinvV3VinvXQ <- 0
        for(d in 1:D){
        tr.XVinvV3VinvXQ <- tr.XVinvV3VinvXQ + sum(diag(XVinvV3VinvX[[d]] %*% Q))
        tr.XVinvV3VinvV3VinvXQ <- tr.XVinvV3VinvV3VinvXQ  + sum(diag(XVinvV3VinvV3VinvX[[d]] %*% Q))
        XVinvV3VinvXQ <- XVinvV3VinvXQ + XVinvV3VinvX[[d]] %*% Q
        }
        
                
        ### Calculation of PV1, and yPV1Py     --------- A
        
        tr.XVinvV1VinvXQXVinvV1VinvXQ <- sum(diag(XVinvV1VinvXQ %*% XVinvV1VinvXQ))
        tr.XVinvV1VinvXQXVinvV2VinvXQ <- sum(diag(XVinvV1VinvXQ %*% XVinvV2VinvXQ))
        tr.XVinvV1VinvXQXVinvV3VinvXQ <- sum(diag(XVinvV1VinvXQ %*% XVinvV3VinvXQ))
        
        
        tr.PV1 <- tr.VinvV1 - tr.XVinvV1VinvXQ
        tr.PV1PV1 <- tr.VinvV1VinvV1 - 2 * tr.XVinvV1VinvV1VinvXQ + tr.XVinvV1VinvXQXVinvV1VinvXQ
        tr.PV1PV2 <- tr.XVinvV1VinvXQXVinvV2VinvXQ
        tr.PV1PV3 <- tr.VinvV1VinvV3.a - 2 * tr.XVinvV1VinvV3VinvX.aQ + tr.XVinvV1VinvXQXVinvV3VinvXQ
        
        yPV1Py <- yVinvV1Vinvy - yVinvV1VinvX %*% Q %*% t(yVinvXa) - yVinvXa %*% Q %*% t(yVinvV1VinvX) + yVinvXa %*% Q %*% SumXVinvV1VinvX %*% Q %*% t(yVinvXa)
        
        
        ### Calculation of PV2 and yPV2Py      --------- B
        
        tr.XVinvV2VinvXQXVinvV2VinvXQ <- sum(diag(XVinvV2VinvXQ %*% XVinvV2VinvXQ))
        tr.XVinvV2VinvXQXVinvV1VinvXQ <- sum(diag(XVinvV2VinvXQ %*% XVinvV1VinvXQ))
        tr.XVinvV2VinvXQXVinvV3VinvXQ <- sum(diag(XVinvV2VinvXQ %*% XVinvV3VinvXQ))
        
        tr.PV2 <- tr.VinvV2 - tr.XVinvV2VinvXQ
        tr.PV2PV2 <- tr.VinvV2VinvV2 - 2 * tr.XVinvV2VinvV2VinvXQ + tr.XVinvV2VinvXQXVinvV2VinvXQ
        tr.PV2PV1 <- tr.XVinvV2VinvXQXVinvV1VinvXQ
        tr.PV2PV3 <- tr.VinvV2VinvV3.b - 2 * tr.XVinvV2VinvV3VinvX.bQ + tr.XVinvV2VinvXQXVinvV3VinvXQ
        
        yPV2Py <- yVinvV2Vinvy - yVinvV2VinvX %*% Q %*% t(yVinvXb) - yVinvXb %*% Q %*% t(yVinvV2VinvX) + yVinvXb %*% Q %*% SumXVinvV2VinvX %*% Q %*% t(yVinvXb)
        
        
        ### Calculation of PV3 and yPV3Py      --------- TOTAL A and B
        
        tr.XVinvV3VinvXQXVinvV3VinvXQ <- sum(diag(XVinvV3VinvXQ %*% XVinvV3VinvXQ))
        
        tr.PV3 <- tr.VinvV3 - tr.XVinvV3VinvXQ 
        tr.PV3PV3 <- tr.VinvV3VinvV3 - 2 * tr.XVinvV3VinvV3VinvXQ + tr.XVinvV3VinvXQXVinvV3VinvXQ
        
        yPV3Py <- yVinvV3Vinvy - yVinvV3VinvX %*% Q %*% t(yVinvX) - yVinvX %*% Q %*% t(yVinvV3VinvX) + yVinvX %*% Q %*% SumXVinvV3VinvX %*% Q %*% t(yVinvX)
        
        
        
        ### Scores and elements of Fisher information Matrix 
        ### F11, F22, F12, F33, F44, F34  for A / B
        
        S1 <- -0.5 * tr.PV1 + 0.5 * yPV1Py
        S2 <- -0.5 * tr.PV2 + 0.5 * yPV2Py   
        S3 <- -0.5 * tr.PV3 + 0.5 * yPV3Py
        
        Ssig <- c(S1, S2, S3)
        
        
        F11  <- 0.5 * tr.PV1PV1
        F22  <- 0.5 * tr.PV2PV2
        F12  <- 0.5 * tr.PV1PV2
        
        F13  <- 0.5 * tr.PV1PV3
        F23  <- 0.5 * tr.PV2PV3
        F33  <- 0.5 * tr.PV3PV3
        
        
        ### FINAL Fisher information Matrix
        Fsig <- matrix(c(F11, F12, F13, F12, F22, F23, F13, F23, F33),ncol=3)
        SumFsig <- abs(sum(Fsig))
        # print(det(Fsig))
        # print(SumFsig)
        #if (abs(det(Fsig)) < 0.000000001 || SumFsig > 10000000) {
            # print(ITER)
        #    ITER <- MAXITER
        #    Bad <- Bad + 1
        #    print("Bad det Fsig or SumFsig")
        #    break }
        
        # print(ITER)
    
        Fsig.inv <- solve(Fsig)
        
        ### Fisher-Scoring Algorithm
        dif <- Fsig.inv %*% Ssig
        
        #################################################################
        
        theta.f <- theta.f + dif
    
        sigma.fa <- theta.f[1,1]
        sigma.fb <- theta.f[2,1]
        rho <- theta.f[3,1]
        
        ### Stopping criterion
        # print(theta.f)
        
        if(abs(dif[1,1])<0.00001 && abs(dif[2,1])<0.00001 && abs(dif[3,1])<0.00001)
        break
    
        # print(Q)
        # print(sigma.fa)
        # print(sigma.fb)
        # print(rho)
        # results3 <- data.frame(theta.f, Fsig)
        # results3 <- as.data.frame(t(results3))
        # write.table(results3, file="REML.txt", sep="\t")
    
        # x<-"ITER maggiore di 49"
        # z<-"ITER minore di 49"
        # if (ITER>49) print(x) else print(z)
        
    }
    
    if (sigma.fa < 0 || sigma.fb < 0 || rho < -1 || rho > 1 ) {
        ITER <- MAXITER
        print("Bad parameters")
        Bad <- Bad + 1 }
    
    return(list(as.vector(theta.f), Fsig, ITER, Bad, Q))
}
