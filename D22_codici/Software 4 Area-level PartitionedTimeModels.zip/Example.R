#######################################################################
###
###           Example of usage for Partitioned Fay-Herriot
###                            Models
###
### Author: Maria Chiara Pagliarella
### File name: Example.R
### Updated: December, 2010
###
#######################################################################

rm(list=ls(all=TRUE))

### Establishing the folder where data and routine files are located.
setwd("C:/PartFHModel/")

### Call functions: H3area, REMLarea, BETA.U.area, mse.area, Interval, pvalueBeta
###                 REMLarea.corr, BETA.U.area.corr, mse.area.corr, Interval.corr, pvalueBeta.corr
###                 REMLarea.2corr, BETA.U.area.2corr, mse.area.2corr, Interval.2corr and pvalueBeta.2corr
source("H3.R")
source("REML.R")
source("EstimationBETA.R")
source("EstimationMSE.R")
source("IC.R")
source("REMLcorr.R")
source("EstimationBETAcorr.R")
source("EstimationMSEcorr.R")
source("ICcorr.R")
source("REML2corr.R")
source("EstimationBETA2corr.R")
source("EstimationMSE2corr.R")
source("IC2corr.R")

### Reading data
data <- read.table(file = "dataExample.txt", header = T)

X <- as.matrix(data[,4:(ncol(data)-2)])
p <- ncol(X)
ydt <- data[,ncol(data)-1]
D <- length(unique(data[,1]))*2
Da <- Db <- D/2
md <- rep(length(unique(data[,3])), D)
M <- sum(md)
sigma2edt <- data[,ncol(data)]


### Calculating H3 and REML variance estimates
sigma.0 <- H3area(X, ydt, D, md, sigma2edt)



### Partitioned Fay-Herriot Model 1 with independent time effects
### Arguments: (X, ydt, D, Da, Db, md, sigma2edt, sigma.0, MAXITER = 100)
fit1 <- REMLarea(X, ydt, D, Da, Db, md, sigma2edt, sigma.0 = sigma.0, MAXITER = 100)
sigmaua.hat <- fit1[[1]]
sigmaub.hat <- fit1[[2]]
if(sigmaua.hat<0) {
    write.table(data.frame(sigmaua.hat), file="VAR_A.NEGATIVE.txt", append=TRUE)
    sigmaua.hat <- 0
}
if(sigmaub.hat<0) {
    write.table(data.frame(sigmaub.hat), file="VAR_B.NEGATIVE.txt", append=TRUE)
    sigmaub.hat <- 0
}


### Arguments: (X, ydt, D, Da, Db, md, sigma2edt, sigmaua, sigmaub)
beta.u.hat <- BETA.U.area(X, ydt, D, Da, Db, md, sigma2edt, sigmaua=sigmaua.hat,
                         sigmaub=sigmaub.hat)   
beta0.hat <- beta.u.hat[1:p]
beta1.hat <- beta0.hat

### Confidence intervals for beta and sigma_a/sigma_b 
### with level of precision 90%
Int <- Interval(fit1, 0.90)
             beta0.hat-Int[[4]]
             beta0.hat+Int[[4]]

MinSigma1 <- c(Int[[8]], Int[[11]], Int[[14]])
MaxSigma1 <- c(Int[[9]], Int[[12]], Int[[15]])
TestSigma1 <- c(Int[[10]], Int[[13]], Int[[16]])
Int.sigma <- data.frame(MinSigma1,MaxSigma1,TestSigma1)
row.names(Int.sigma)<-c("Sigma.A","Sigma.B","Sigma.Dif")
Int.sigma

### P-value of beta
(pvalueB <- pvalueBeta(beta0.hat, fit1))
                pvalueB>0.10
udt.hat <- beta.u.hat[-(1:p)]

### EBLUP of the population parameter
mudt.hat <- as.vector( X %*% beta0.hat + udt.hat)

sqrt.mse <- sqrt(mse.area(X, D, Da, Db, md, sigma2edt, sigmaua=sigmaua.hat, 
            sigmaub=sigmaub.hat, F11=fit1[[3]][1,1], F22=fit1[[3]][2,2]))

residual <- ydt - mudt.hat
Henderson3 <- sigma.0

###############################################################################


### Reading data
data <- read.table(file = "dataExample.txt", header = T)

X <- as.matrix(data[,4:(ncol(data)-2)])
p <- ncol(X)
ydt <- data[,ncol(data)-1]
D <- length(unique(data[,1]))*2
Da <- Db <- D/2
md <- rep(length(unique(data[,3])), D)
M <- sum(md)
mda <- rep(length(unique(data[,3])), Da)
Ma <- sum(mda)
mdb <- rep(length(unique(data[,3])), Db)
Mb <- sum(mdb)
sigma2edt <- data[,ncol(data)]

### Calculating H3 and REML variance estimates
sigma.0 <- H3area(X, ydt, D, md, sigma2edt)

### Partitioned Fay-Herriot Model 2 with only one 
### factor of correlation rho
###Arguments: (X, ydt, D, Da, Db, md, mda, mdb, sigma2edt, sigma.fa, sigma.fb, rho=0.2, MAXITER = 100)
fit1 <- REMLarea.corr(X, ydt, D, Da, Db, md, mda, mdb, sigma2edt, sigma.fa=sigma.0, sigma.fb=sigma.0, rho=0.2, MAXITER = 100)

sigmaua.hat <- fit1[[1]][1]
sigmaub.hat <- fit1[[1]][2]
rho.hat <- fit1[[1]][3]

### Arguments: (X, ydt, D, Da, Db, md, mda, sigma2edt, sigmaua, sigmaub, rho)
### Take care that Omega.a is calculate with index mda and Omega.b is calculated without index mdb, only with md
beta.u.hat <- BETA.U.area.corr(X, ydt, D, Da, Db, md, mda, sigma2edt, sigmaua=sigmaua.hat, sigmaub=sigmaub.hat, rho=rho.hat)
beta0.hat <- beta.u.hat[1:p]
beta2.hat <- beta0.hat

### Confidence intervals for beta, sigma_a/sigma_b and rho
### with level of precision 90%

Int.corr <- Interval.corr(fit1, 0.90)
            beta0.hat-Int.corr[[5]]
            beta0.hat+Int.corr[[5]]

MinSigma2 <- c(Int.corr[[9]], Int.corr[[12]], Int.corr[[15]])
MaxSigma2 <- c(Int.corr[[10]], Int.corr[[13]], Int.corr[[16]])
TestSigma2 <- c(Int.corr[[11]], Int.corr[[14]], Int.corr[[17]])
Int.corr.sigma <- data.frame(MinSigma2,MaxSigma2,TestSigma2)
row.names(Int.corr.sigma)<-c("Sigma.A","Sigma.B","Sigma.Dif")
Int.corr.sigma

MinRho2 <- c(Int.corr[[18]])
MaxRho2 <- c(Int.corr[[19]])
TestRho2 <- c(Int.corr[[20]])
Int.corr.rho <- data.frame(MinRho2,MaxRho2,TestRho2)
Int.corr.rho

### P-value of beta
(pvalueB.corr <- pvalueBeta.corr(beta0.hat, fit1))
                 pvalueB.corr>0.10
udt.hat.corr <- beta.u.hat[-(1:p)]

### EBLUP of the population parameter
mudt.hat.corr <- as.vector(X %*% beta0.hat + udt.hat.corr)

sqrt.mse.corr <- sqrt(mse.area.corr(X, D, Da, Db, md, mda, mdb, sigma2edt, sigmaua=sigmaua.hat, sigmaub=sigmaub.hat, rho=rho.hat, F11=fit1[[2]][1,1], F22=fit1[[2]][2,2], F13=fit1[[2]][1,3], F23=fit1[[2]][2,3], F33=fit1[[2]][3,3]))

residual.corr <- ydt - mudt.hat.corr


###############################################################################

### Reading data
data <- read.table(file = "dataExample.txt", header = T)

X <- as.matrix(data[,4:(ncol(data)-2)])
p <- ncol(X)
ydt <- data[,ncol(data)-1]
D <- length(unique(data[,1]))*2
Da <- Db <- D/2
md <- rep(length(unique(data[,3])), D)
M <- sum(md)
mda <- rep(length(unique(data[,3])), Da)
Ma <- sum(mda)
mdb <- rep(length(unique(data[,3])), Db)
Mb <- sum(mdb)
sigma2edt <- data[,ncol(data)]

### Calculating H3 and REML variance estimates
sigma.0 <- H3area(X, ydt, D, md, sigma2edt)

### Partitioned Fay-Herriot Model 3 with two
### factor of correlation rho_a and rho_b
###Arguments: (X, ydt, D, Da, Db, md, mda, mdb, sigma2edt, sigma.fa, sigma.fb, rhoa, rhob, MAXITER = 100)
fit1 <- REMLarea.2corr(X, ydt, D, Da, Db, md, mda, mdb, sigma2edt, sigma.fa=sigma.0, sigma.fb=sigma.0, rhoa=0.1, rhob=0.3, MAXITER = 100)

sigmaua.hat <- fit1[[1]][1]
sigmaub.hat <- fit1[[1]][3]
rhoa.hat <- fit1[[1]][2]
rhob.hat <- fit1[[1]][4]

### Arguments: (X, ydt, D, Da, Db, md, mda, sigma2edt, sigmaua, sigmaub, rhoa, rhob)
### Take care that Omega.a is calculate with index mda and Omega.b is calculated without index mdb, only with md
beta.u.hat <- BETA.U.area.2corr(X, ydt, D, Da, Db, md, mda, sigma2edt, sigmaua=sigmaua.hat, sigmaub=sigmaub.hat, rhoa=rhoa.hat, rhob=rhob.hat)   
beta0.hat <- beta.u.hat[1:p]
beta3.hat <- beta0.hat


### Confidence intervals for beta, sigma_a/sigma_b,
### rho_a and rho_b with level of precision 90%

Int.2corr <- Interval.2corr(fit1, 0.90)
            beta0.hat-Int.2corr[[7]]
            beta0.hat+Int.2corr[[7]]

MinSigma3 <- c(Int.2corr[[11]], Int.2corr[[14]], Int.2corr[[17]])
MaxSigma3 <- c(Int.2corr[[12]], Int.2corr[[15]], Int.2corr[[18]])
TestSigma3 <- c(Int.2corr[[13]], Int.2corr[[16]], Int.2corr[[19]])
Int.2corr.sigma <- data.frame(MinSigma3,MaxSigma3,TestSigma3)
row.names(Int.2corr.sigma)<-c("Sigma.A","Sigma.B","Sigma.Dif")
Int.2corr.sigma

MinRho3 <- c(Int.2corr[[20]], Int.2corr[[23]], Int.2corr[[26]])
MaxRho3 <- c(Int.2corr[[21]], Int.2corr[[24]], Int.2corr[[27]])
TestRho3 <- c(Int.2corr[[22]], Int.2corr[[25]], Int.2corr[[28]])
Int.2corr.rho <- data.frame(MinRho3,MaxRho3,TestRho3)
row.names(Int.2corr.rho)<-c("Rho.A","Rho.B","Rho.Dif")
Int.2corr.rho

### P-value of beta
(pvalueB.2corr <- pvalueBeta.2corr(beta0.hat, fit1))
                 pvalueB.2corr>0.10
udt.hat.2corr <- beta.u.hat[-(1:p)]


### EBLUP of the population parameter
mudt.hat.2corr <- as.vector(X %*% beta0.hat + udt.hat.2corr)

sqrt.mse.2corr <- sqrt(mse.area.2corr(X, D, Da, Db, md, mda, mdb, sigma2edt, sigmaua=sigmaua.hat, sigmaub=sigmaub.hat, rhoa=rhoa.hat, rhob=rhob.hat, F11=fit1[[2]][1,1], F22=fit1[[2]][2,2], F12=fit1[[2]][1,2], F33=fit1[[2]][3,3], F44=fit1[[2]][4,4], F34=fit1[[2]][3,4]))

residual.2corr <- ydt - mudt.hat.2corr



### Create .txt files in the folder that contains for
### the resulting output
write.table(data.frame(data[,1:3], 
Direct=ydt, EBLUP1=mudt.hat, EBLUP2=mudt.hat.corr, EBLUP3=mudt.hat.2corr,
MSE.Direct=sqrt(sigma2edt), MSE.EBLUP1=sqrt.mse, MSE.EBLUP2=sqrt.mse.corr, MSE.EBLUP3=sqrt.mse.2corr),
file="EBLUP_Example.txt", row.names=FALSE, sep="\t")

write.table(data.frame(names(data)[4:(ncol(data)-2)], 
beta1=beta1.hat, Std.error.beta1=Int[[4]],
beta2=beta2.hat, Std.error.beta2=Int.corr[[5]],
beta3=beta3.hat, Std.error.beta3=Int.corr[[7]]),
file="beta_Example.txt",
row.names=FALSE, sep="\t")

write.table(data.frame(data[,1:3], udt1=udt.hat, udt2=udt.hat.corr, udt3=udt.hat.2corr),
file="u_Example.txt",
row.names=FALSE, sep="\t")

write.table(data.frame(data[,1:3], res1=residual, res2=residual.corr, res3=residual.2corr),
file="res_Example.txt",
row.names=FALSE, sep="\t")

write.table(data.frame(Int.sigma,
Int.corr.sigma,Int.2corr.sigma),
file="IntervalSigma_Example.txt",
row.names=c("Sigma.A","Sigma.B","Sigma.Dif"), sep="\t")

write.table(data.frame(Int.corr.rho,
Int.2corr.rho),
file="IntervalRho_Example.txt",
row.names=c("Rho.A","Rho.B","Rho.Dif"), sep="\t")

write.table(data.frame(names(data)[4:(ncol(data)-2)],
beta1=beta1.hat, pvalueB1=pvalueB,
beta2=beta2.hat, pvalueB2=pvalueB.corr,
beta3=beta3.hat, pvalueB3=pvalueB.2corr),
file="pvalueB_Example.txt",
row.names=FALSE, sep="\t")

write.table(data.frame(Henderson3),
file="H3_Example.txt",
row.names=FALSE, sep="\t")

rm(list=ls(all=TRUE))
