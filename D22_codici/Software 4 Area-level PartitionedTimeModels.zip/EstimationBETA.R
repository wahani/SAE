###############################################################################
###
###          Area level Patitioned F-H model with independent time effects
###                             Pagliarella model 1
###
###
### AUTOR: Maria Chiara Pagliarella
### File name: EstimationBETA.R
### Updated: November 2009
###
### WORKING PROGRESS
###
###############################################################################


BETA.U.area <- function(X, ydt, D, Da, Db, md, sigma2edt, sigmaua, sigmaub) {


    p <- ncol(X)
    i <- list(1:md[1])
    mdcum <- cumsum(md)
    Db <- D-Da
    
    for(d in 2:D)
        i[[d]] <- (mdcum[d-1]+1):mdcum[d]
        
    ia <- i[1:Da]
    ib <- i[(Da+1):D]
    
    
    yd <- Xd <- list()
    for(d in 1:D) {
        yd[[d]] <- ydt[i[[d]]]
        Xd[[d]] <- X[i[[d]],]
    }
    
    
    Vd.inv <- list()
    Q.inv <- matrix(0, nrow=p, ncol=p)
    XVy <-0
    for(d in 1:D) {      
        ### Elements of the variance matrix
        if (d <= Da)
            vd<-(sigmaua + sigma2edt)[ia[[d]]]
        else
            vd<-(sigmaub + sigma2edt)[i[[d]]]
             
        ### Inverse matrix of the variance and submatrices
        Vd.inv[[d]] <- diag(1/vd)
        
        ### Inverse of Q. Next we calculate Q
        Q.inv <- Q.inv + t(Xd[[d]])%*%Vd.inv[[d]]%*%Xd[[d]]
        
        ### Product between X^t_d,  V^-1_d and y_d for all d submatrices
        XVy <- XVy + t(Xd[[d]])%*%Vd.inv[[d]]%*%yd[[d]]
    }
    Q <- solve(Q.inv)
    
    beta <- Q%*%XVy
    
    
    ua <- ub <- list()
    for (d in 1:D){
        if (d <= Da) {
            ua[[d]] <- sigmaua*Vd.inv[[d]]%*%(yd[[d]]-Xd[[d]]%*%beta)}
        else {
            ub[[d]] <- sigmaub*Vd.inv[[d]]%*%(yd[[d]]-Xd[[d]]%*%beta)}
    }
    
    ua<-as.matrix(unlist(ua))
    ub<-as.matrix(unlist(ub))
    u <- c(ua,ub)
    
    return(c(beta,u))
}
