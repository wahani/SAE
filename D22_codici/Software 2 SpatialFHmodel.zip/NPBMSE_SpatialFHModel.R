#####################################################################
###
### This function gives a nonparametric bootstrap MSE estimator of 
### the EB estimator under a Spatial FH model, in which random 
### effects follow a Simultaneously Autorregressive (SAR) process.
### The EB estimator is obtained either by REML or by FH fitting 
### methods.
###
### Work for European project SAMPLE
###
### Author: Nicola Salvati and Isabel Molina
### File name: NPBMSE_SpatialFHModel.R
### Updated: February 8th, 2011
###
#####################################################################

source("Fitting_SpatialFHModel.R")

NPBMSE.SpatialFHmodel<-function(X,y,Dvec,W,n.boot,method="REML",
seed=Sys.time()){

# Set the seed for random number generation, required for the 
# bootstrap method.

set.seed(seed)

m<-dim(X)[1]  # Sample size or number of areas
p<-dim(X)[2]  # Num. of auxiliary variables (including intercept)

# Fit the model to initial sample data using the given method

results.SpFH<-try(fitSpatialFH(X,y,Dvec,W,method))

# Initial estimators of model coefficients, variance and spatial 
# correlation which will act as true values in the bootstrap 
# procedure.

Bstim.boot<-results.SpFH$modelcoefficients[,1]
rho.boot<-results.SpFH$spatialcorr
sigma2.boot<-results.SpFH$variance

# Auxiliary calculations

I<-diag(1,m)
Wt<-t(W)
Xt<-t(X)

IrhoW<-I-rho.boot*W
IrhoWt<-t(IrhoW)
Ar<-solve(IrhoWt%*%IrhoW)
Gr<-sigma2.boot*Ar
Vr<-Gr+I*Dvec
Vri<-solve(Vr)
Qr<-solve(Xt%*%Vri%*%X)

# Analytical estimators of g1 and g2, used for the bias-corrected 
# PB MSE estimator.

g1sp<-rep(0,m)
g2sp<-rep(0,m)

XtVri<-Xt%*%Vri
Qr<-solve(XtVri%*%X)

# Calculate g1 and g2

Ga<-Gr-Gr%*%Vri%*%Gr
Gb<-Gr%*%t(XtVri)
Xa<-matrix(0,1,p)

for (i in 1:m) {
  g1sp[i]<-Ga[i,i]
  Xa[1,]<-X[i,]-Gb[i,]
  g2sp[i]<-Xa%*%Qr%*%t(Xa)
}

# Residual vectors

res<-y-X%*%Bstim.boot
vstim<-Gr%*%Vri%*%res

# Calculate covariance matrices of residual vectors

VG<-Vr-Gr
P<-Vri-Vri%*%X%*%Qr%*%Xt%*%Vri

Ve<-VG%*%P%*%VG
Vu<-IrhoW%*%Gr%*%P%*%Gr%*%IrhoWt

# Square roots of covariance matrices

VecVe0<-eigen(Ve)$vectors
VecVe<-VecVe0[,1:(m-p)]
ValVe0<-eigen(Ve)$values
Valve<-diag(sqrt(1/ValVe0[1:(m-p)]))
Vei05<-VecVe%*%Valve%*%t(VecVe)

VecVu0<-eigen(Vu)$vectors
VecVu<-VecVu0[,1:(m-p)]
ValVu0<-1/(eigen(Vu)$values)
ValVu<-diag(sqrt(ValVu0[1:(m-p)]))
Vui05<-VecVu%*%ValVu%*%t(VecVu)

# Standardize residual vectors

ustim<-as.real(Vui05%*%((IrhoW)%*%vstim))
estim<-as.real(Vei05%*%(res-vstim))
sdu<-sqrt(sigma2.boot)

u.std<-rep(0,m)
e.std<-rep(0,m)

for (i in 1:m){
  u.std[i]<-(sdu*(ustim[i]-mean(ustim)))/
  sqrt(mean((ustim-mean(ustim))^2))
  e.std[i]<-(estim[i]-mean(estim))/
  sqrt(mean((estim-mean(estim))^2))
}

# Bootstrap algorithm starts

difmse.npb<-matrix(0,m,1)
difg3Spat.npb<-matrix(0,m,1)
g1sp.aux<-matrix(0,m,1)
g2sp.aux<-matrix(0,m,1)
difg1sp.npb<-matrix(0,m,1)
difg2sp.npb<-matrix(0,m,1)

countdetB<-0

for (boot in 1:n.boot) {

  cat("Bootstrap iteration",boot,"\n")

  # Generate boostrap data
  
  u.boot<-sample(u.std,m,replace=TRUE)
  e.samp<-sample(e.std,m,replace=TRUE)
  e.boot<-sqrt(Dvec)*e.samp
  v.boot<-solve(IrhoW)%*%u.boot
  theta.boot<-X%*%Bstim.boot+v.boot
  direct.boot<-theta.boot+e.boot

  # Fit the model to bootstrap data

  results.SpFH.boot<-fitSpatialFH(X,direct.boot[,1],Dvec,W,method)

  # While the estimators are not satisfactory we generate a new sample
  
  conv<-results.SpFH.boot$convergence
  v<-results.SpFH.boot$variance
  r<-results.SpFH.boot$spatialcorr
  print(conv)
  print(c(v,r))

  if (conv==FALSE) {v<-0}
  if (is.na(v)==TRUE) {v<-0}
  if (is.na(r)==TRUE) {r<-1}

  while ((v<0.0001)|(r<(-0.999))|(r>0.999)){
    print("New sample")
    u.boot<-sample(u.std,m,replace=TRUE)
    e.samp<-sample(e.std,m,replace=TRUE)
    v.boot<-solve(IrhoW)%*%u.boot
    theta.boot<-X%*%Bstim.boot+v.boot
    direct.boot<-theta.boot+e.boot
    results.SpFH.boot<-fitSpatialFH(X,direct.boot[,1],Dvec,W,method)
    conv<-results.SpFH.boot$convergence
    v<-results.SpFH.boot$variance
    r<-results.SpFH.boot$spatialcorr
    if (conv==FALSE) {v<-0}
    if (is.na(v)==TRUE) {v<-0}
    if (is.na(r)==TRUE) {r<-1}
  }

  Bstim.ML.boot<-results.SpFH.boot$modelcoefficients[,1]
  rho.ML.boot<-results.SpFH.boot$spatialcorr
  sigma2.ML.boot<-results.SpFH.boot$variance
  thetaEB.SpFH.boot<-results.SpFH.boot$EBpredictor

  # Nonparametric bootstrap estimator of g3

  Bstim.sblup<-Qr%*%XtVri%*%direct.boot[,1]
  thetaEB.SpFH.sblup.boot<-X%*%Bstim.sblup+Gr%*%Vri%*%
  (direct.boot[,1]-X%*%Bstim.sblup)

  difg3Spat.npb[,1]<-difg3Spat.npb[,1]+
  (thetaEB.SpFH.boot-thetaEB.SpFH.sblup.boot)^2

  # Naive nonparametric bootstrap MSE

  difmse.npb[,1]<-difmse.npb[,1]+(thetaEB.SpFH.boot[,1]-theta.boot)^2

  # g1 and g2 for each bootstrap sample

  A<-solve((I-rho.ML.boot*Wt)%*%(I-rho.ML.boot*W))
  G<-sigma2.ML.boot*A
  V<-G+I*Dvec
  Vi<-solve(V)
  XtVi<-Xt%*%Vi
  Q<-solve(XtVi%*%X)

  Ga<-G-G%*%Vi%*%G
  Gb<-G%*%Vi%*%X
  Xa<-matrix(0,1,p)

  for (i in 1:m){
    g1sp.aux[i]<-Ga[i,i] 
    Xa[1,]<-X[i,]-Gb[i,]
    g2sp.aux[i]<-Xa%*%Q%*%t(Xa)
  }

  difg1sp.npb<-difg1sp.npb+g1sp.aux
  difg2sp.npb<-difg2sp.npb+g2sp.aux

} # End of bootstrap cycle

# Final naive nonparametric bootstrap MSE estimator
mse.npb<-difmse.npb[,1]/n.boot

# Final bias-corrected nonparametric bootstrap MSE estimator
g3Spat.npb<-difg3Spat.npb/n.boot
g1sp.npb<-difg1sp.npb/n.boot
g2sp.npb<-difg2sp.npb/n.boot
mse.npb2<-2*(g1sp+g2sp)-difg1sp.npb[,1]/n.boot-difg2sp.npb[,1]/n.boot+
difg3Spat.npb[,1]/n.boot

return (data.frame(NPBmse=mse.npb,bcNPBmse=mse.npb2))

}
