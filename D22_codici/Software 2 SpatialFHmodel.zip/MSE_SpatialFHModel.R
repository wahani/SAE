###############################################################################
###
### This function gives the analytical MSE estimator of the EB estimator 
### under a Spatial FH model, in which random effects follow a 
### Simultaneously Autorregressive (SAR) process.
### The EB estimator is obtained by REML fitting method
###
### Work for European project SAMPLE
###
### Author: Isabel Molina Peralta
### File name: MSE_SpatialFHModel.R
### Updated: March 15th, 2010
###
###############################################################################

MSE.SpatialFHmodel<-function(X,Dvec,A,rho,W,method="REML"){

  m<-dim(X)[1]  # Sample size or number of areas
  p<-dim(X)[2]  # Number of auxiliary variables

  # Initialize vectors containing the values of g1-g4 and mse for each area
  g1d<-rep(0,m)
  g2d<-rep(0,m)
  g3d<-rep(0,m)
  g4d<-rep(0,m)
  mse2d.aux<-rep(0,m)
  mse2d<-rep(0,m)
  
  # Auxiliary calculations
  I<-diag(1,m)
  Xt<-t(X)
  Wt<-t(W)
  Ci<-solve((I-rho*Wt)%*%(I-rho*W))
  G<-A*Ci
  V<-G+I*Dvec
  Vi<-solve(V)
  XtVi<-Xt%*%Vi
  Q<-solve(XtVi%*%X)
  
  Ga<-G-G%*%Vi%*%G
  
  Gb<-G%*%Vi%*%X
  Xa<-matrix(0,1,p)
  
  for (i in 1:m) { 
    g1d[i]<-Ga[i,i]  # g1 contains the diagonal elements of Ga
    Xa[1,]<-X[i,]-Gb[i,]
    g2d[i]<-Xa%*%Q%*%t(Xa)
  }
  
  # Auxiliary calculations for g3
  derRho<-2*rho*Wt%*%W-W-Wt
  Amat<-(-1)*A*(Ci%*%derRho%*%Ci)
  P<-Vi-t(XtVi)%*%Q%*%XtVi
  PCi<-P%*%Ci
  PAmat<-P%*%Amat
  
  Idev<-matrix(0,2,2)
  Idev[1,1]<-(0.5)*sum(diag((PCi%*%PCi)))
  Idev[1,2]<-(0.5)*sum(diag((PCi%*%PAmat)))
  Idev[2,1]<-Idev[1,2]
  Idev[2,2]<-(0.5)*sum(diag((PAmat%*%PAmat)))
  Idevi<-solve(Idev)
  
  ViCi<-Vi%*%Ci
  ViAmat<-Vi%*%Amat
  
  # Calculation of g3
  l1<-ViCi-A*ViCi%*%ViCi
  l1t<-t(l1)
  l2<-ViAmat-A*ViAmat%*%ViCi
  l2t<-t(l2)
  L<-matrix(0,2,m)
  for (i in 1:m)
  {
    L[1,]<-l1t[i,]
    L[2,]<-l2t[i,]
    g3d[i]<-sum(diag(L%*%V%*%t(L)%*%Idevi))
  }
  
  mse2d.aux<-g1d+g2d+2*g3d
  
  # Bias correction of Singh et al
  
  psi<-diag(Dvec,m)
  D12aux<-(-1)*(Ci%*%derRho%*%Ci)
  D22aux<-2*A*Ci%*%derRho%*%Ci%*%derRho%*%Ci-2*A*Ci%*%Wt%*%W%*%Ci
  D<-(psi%*%Vi%*%D12aux%*%Vi%*%psi)*(Idevi[1,2]+Idevi[2,1])+psi%*%Vi%*%D22aux%*%Vi%*%psi*Idevi[2,2]
  
  for (i in 1:m) {g4d[i]<-(0.5)*D[i,i]}
  
  # Computation of estimated MSE of Singh et al
  
  mse2d<-mse2d.aux-g4d
  
  return(mse=mse2d)  

}
