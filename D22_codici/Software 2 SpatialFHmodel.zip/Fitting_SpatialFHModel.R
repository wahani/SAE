###############################################################################
###
### This function fits a spatial Fay-Herriot model,
### in which random effects follow a Simultaneously Autorregressive (SAR) process
### Fitting method can be chosen between REML and ML methods
###
### Work for European project SAMPLE
###
### Author: Isabel Molina Peralta
### File name: Fitting_SpatialFHModel.R
### Updated: March 15th, 2010
###
###############################################################################


fitSpatialFH<-function(X,y,Dvec,W,method="REML",MAXITER=500) {

  m<-length(y)  # Sample size or number of areas
  p<-dim(X)[2]  # Num. of X columns of num. of auxiliary variables (including intercept)
  Xt<-t(X)
  yt<-t(y)
  Wt<-t(W)
  I<-diag(1,m)
  
  # Initialize vectors containing estimators of variance and spatial correlation
  par.stim<-matrix(0,2,1)
  stime.fin<-matrix(0,2,1)
  
  # Initialize scores vector and Fisher information matrix
  s<-matrix(0,2,1)
  Idev<-matrix(0,2,2)

  # Initial value of variance set to the mean of sampling variances Dvec
  # Initial value of spatial correlation set to 0.5
  sigma2.u.stim.S<-0
  rho.stim.S<-0
  
  sigma2.u.stim.S[1]<-median(Dvec)
  rho.stim.S[1]<-0.5
  
  # Fisher-scoring algorithm for REML estimators start
  
  if (method=="REML"){
  
    k<-0
    diff.S<-1
  
    while ((diff.S>0.0001)&(k<MAXITER)){
    
      k<-k+1
      # Derivative of covariance matrix V with respect to variance
      derSigma<-solve((I-rho.stim.S[k]*Wt)%*%(I-rho.stim.S[k]*W))
      # Derivative of covariance matrix V with respect to spatial correlation parameter
      derRho<-2*rho.stim.S[k]*Wt%*%W-W-Wt
      derVRho<-(-1)*sigma2.u.stim.S[k]*(derSigma%*%derRho%*%derSigma)
      # Covariance matrix and inverse covariance matrix
      V<-sigma2.u.stim.S[k]*derSigma+I*Dvec
      Vi<-solve(V)
      # Matrix P and coefficients'estimator beta
      XtVi<-Xt%*%Vi
      Q<-solve(XtVi%*%X)
      P<-Vi-t(XtVi)%*%Q%*%XtVi
      b.s<-Q%*%XtVi%*%y
      # Terms involved in scores vector and Fisher information matrix
      PD<-P%*%derSigma
      PR<-P%*%derVRho
      Pdir<-P%*%y
      # Scores vector
      s[1,1]<-(-0.5)*sum(diag(PD))+(0.5)*(yt%*%PD%*%Pdir)
      s[2,1]<-(-0.5)*sum(diag(PR))+(0.5)*(yt%*%PR%*%Pdir)
      # Fisher information matrix
      Idev[1,1]<-(0.5)*sum(diag(PD%*%PD))
      Idev[1,2]<-(0.5)*sum(diag(PD%*%PR))
      Idev[2,1]<-Idev[1,2]
      Idev[2,2]<-(0.5)*sum(diag(PR%*%PR))
      
      # Updating equation
      par.stim[1,1]<-sigma2.u.stim.S[k]
      par.stim[2,1]<-rho.stim.S[k]
      
      stime.fin<-par.stim+solve(Idev)%*%s
      print(stime.fin)
      
      # Restricting the spatial correlation to (-0.999,0.999) and the variance to (0.0001,infty)
      if ((stime.fin[2,1]<=0.999)&(stime.fin[2,1]>=-0.999)&(stime.fin[1,1]>0.0001)){
        sigma2.u.stim.S[k+1]<-stime.fin[1,1]
        rho.stim.S[k+1]<-stime.fin[2,1]
        diff.S<-max(abs(stime.fin-par.stim)/par.stim)
      }else{ diff.S<-0.00001 }
      
    } # End of while
        
  # Fisher-scoring algorithm for REML estimators start

  }else if (method=="ML"){
  
    k<-0
    diff.S<-1
    
    while ((diff.S>0.0001)&(k<MAXITER)){
    
      k<-k+1
      # Derivative of covariance matrix V with respect to variance
      derSigma<-solve((I-rho.stim.S[k]*Wt)%*%(I-rho.stim.S[k]*W))
      # Derivative of covariance matrix V with respect to spatial correlation
      derRho<-2*rho.stim.S[k]*Wt%*%W-W-Wt
      derVRho<-(-1)*sigma2.u.stim.S[k]*(derSigma%*%derRho%*%derSigma)
      # Covariance matrix and inverse covariance matrix
      V<-sigma2.u.stim.S[k]*derSigma+I*Dvec
      Vi<-solve(V)
      # Coefficients'estimator beta and matrix P
      XtVi<-Xt%*%Vi
      Q<-solve(XtVi%*%X)
      P<-Vi-t(XtVi)%*%Q%*%XtVi
      b.s<-Q%*%XtVi%*%y
      # Terms involved in scores vector and Fisher information matrix
      PD<-P%*%derSigma
      PR<-P%*%derVRho
      Pdir<-P%*%y
      ViD<-Vi%*%derSigma
      ViR<-Vi%*%derVRho
      # Scores vector
      s[1,1]<-(-0.5)*sum(diag(ViD))+(0.5)*(yt%*%PD%*%Pdir)
      s[2,1]<-(-0.5)*sum(diag(ViR))+(0.5)*(yt%*%PR%*%Pdir)
      # Fisher information matrix
      Idev[1,1]<-(0.5)*sum(diag(ViD%*%ViD))
      Idev[1,2]<-(0.5)*sum(diag(ViD%*%ViR))
      Idev[2,1]<-Idev[1,2]
      Idev[2,2]<-(0.5)*sum(diag(ViR%*%ViR))
      
      # Updating equation      
      par.stim[1,1]<-sigma2.u.stim.S[k]
      par.stim[2,1]<-rho.stim.S[k]
      
      stime.fin<-par.stim+solve(Idev)%*%s
      
      # Restricting the spatial correlation to (-0.999,0.999) and the variance to (0.0001,infty)
      if ((stime.fin[2,1]<=0.999)&(stime.fin[2,1]>=-0.999)&(stime.fin[1,1]>0.0001)){
        sigma2.u.stim.S[k+1]<-stime.fin[1,1]
        rho.stim.S[k+1]<-stime.fin[2,1]
        diff.S<-max(abs(stime.fin-par.stim)/par.stim)
      }else{ diff.S<-0.00001 }
      
    } # End of while
  # Error message if method is different from REML or ML 
  } else { print("Error: Unknown method") }   
   
  # Final values of estimators     
  rho<-rho.stim.S[k+1]
  sigma2u<-max(sigma2.u.stim.S[k+1],0)
  #print(c(sigma2u,rho))
           
  # Indicator of convergence
  
  if(k<MAXITER) {conv<-TRUE} else {conv<-FALSE}

  # Computation of the coefficients'estimator (Bstim)

  A<-solve((I-rho*Wt)%*%(I-rho*W))
  G<-sigma2u*A
  V<-G+I*Dvec
  Vi<-solve(V)
  XtVi<-Xt%*%Vi
  Q<-solve(XtVi%*%X)
  Bstim<-Q%*%XtVi%*%y
 
  # Significance of the regression coefficients
  
  std.errorbeta<-sqrt(diag(Q))
  tvalue<-Bstim/std.errorbeta
  pvalue<-2*pnorm(abs(tvalue),lower.tail=FALSE)
  
  coef<-data.frame(beta=Bstim,std.errorbeta,tvalue,pvalue)
  
  # Goodness of fit measures: loglikelihood, AIC, BIC
    
  Xbeta<-X%*%Bstim
  resid<-y-Xbeta
  
  loglike<-(-0.5)*(m*log(2*pi)+determinant(V,logarithm=T)$modulus+t(resid)%*%Vi%*%resid)
  
  AIC<-(-2)*loglike+2*(p+2)
  BIC<-(-2)*loglike+(p+2)*log(m)
  
  goodness<-c(loglike=loglike,AIC=AIC,BIC=BIC)

  # Computation of the Spatial EBLUP
  
  res<-y-X%*%Bstim
  thetaSpat<-X%*%Bstim+G%*%Vi%*%res

  return(list(convergence=conv,modelcoefficients=coef,variance=sigma2u,spatialcorr=rho,goodnessoffit=goodness,EBpredictor=thetaSpat))
  
}