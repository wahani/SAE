###############################################################################
###
###              Area level model with independent time effects
###                              SAMPLE project
###
### Author: Agust�n Perez Mart�n
### File name: EstimationMSEindep.R
### Updated: November 25th, 2009
###
###############################################################################

mse.area.indep <- function(X, D, md, sigma2edt, sigmau, Fsig) {

    p <- ncol(X)
    a <- list(1:md[1])
    mdcum <- cumsum(md)
    for(d in 2:D)
        a[[d]] <- (mdcum[d-1]+1):mdcum[d]

    Xd <- Vd.inv <- Sed.inv <- SinvXd <- VinvSinvXd <- g2.a <- list()
    Q.inv <- matrix(0, nrow=p, ncol=p)
    XVy <- 0
    for(d in 1:D) {
        Xd[[d]] <- X[a[[d]],]

        ### Elements of the variance matrix
        vd <- (sigmau + sigma2edt)[a[[d]]]

        ### Inverse matrix of the variance and d submatrices
        Vd.inv[[d]] <- diag(1/vd)

        ### Elements of the variance matrix Sigma_e
        sd <- sigma2edt[a[[d]]]

        ### Inverse matrix of Sigma_ed in all d submatrices
        Sed.inv[[d]] <- diag(1/sd)

        ### Product between Sigma^-1_ed and X_d for all d submatrices
        SinvXd[[d]] <- Sed.inv[[d]]%*%Xd[[d]]

        ### Product between V^-1_d, Sigma^-1_ed and X_d for all d submatrices
        VinvSinvXd[[d]] <- Vd.inv[[d]]%*%SinvXd[[d]]

        ### First part of g2 (the second is its transpose)
        g2.a[[d]] <- Xd[[d]] - sigmau*SinvXd[[d]] + sigmau^2*VinvSinvXd[[d]]

        ### Inverse of Q. Next we calculate Q
        Q.inv <- Q.inv + t(Xd[[d]])%*%Vd.inv[[d]]%*%Xd[[d]]
    }
    Q <- solve(Q.inv)

    ### Elements of the variance matrix
    vd <- sigmau + sigma2edt
    q <- 1/vd - 2*(sigmau/vd^2) + (sigmau^2/vd^3)

    ### Calculation of g
    g1 <- (sigmau*sigma2edt)/vd
    g2 <- list()
    for(d in 1:D)
        g2[[d]] <- diag(g2.a[[d]]%*%Q%*%t(g2.a[[d]]))
    g2 <- unlist(g2)
    g3 <- q/Fsig

    return(g1+g2+2*g3)
}
