###############################################################################
###
###              Area level model with independent time effects
###                              SAMPLE project
###
### Author: Agust�n Perez Mart�n
### File name: ICindep.R
### Updated: November 25th, 2009
###
###############################################################################

Interval.indep <- function(fit, conf=0.95) {
    alfa <- 1-conf
    k <- 1-alfa/2
    z <- qnorm(k)

    Finv <- solve(fit[[2]])

    sigma.std.err <- z*sqrt(Finv[1,1])
    beta.std.err <- z*sqrt(as.vector(diag(fit[[3]])))

    return( list(sigma.std.err, beta.std.err) )
}
