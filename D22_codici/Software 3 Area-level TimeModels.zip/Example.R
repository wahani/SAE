###############################################################################
###
###                         Area-level time models
###                              SAMPLE project
###
### Author: Agust�n P�rez Mart�n
### File name: Example.R
### Updated: November 25th, 2009
###
###############################################################################

### Establishing the folder where data and routine files are located.
setwd("C:/Areatimemodel/")

### Call the functions: H3area, REMLarea.indep, BETA.U.area.indep,
###                     mse.area.indep, Interval.indep,
###                     REMLarea.autocorr, BETA.U.area.autocorr,
###                     mse.area.autocorr, Interval.autocorr and pvalue
source("H3.R")
source("REMLindep.R")
source("EstimationBETAindep.R")
source("EstimationMSEindep.R")
source("ICindep.R")
source("REMLautocorr.R")
source("EstimationBETAautocorr.R")
source("EstimationMSEautocorr.R")
source("ICautocorr.R")
source("pvalue.R")


### Reading data
data <- read.table(file = "dataExample.txt", header = T)

X <- as.matrix(data[,3:(ncol(data)-2)])
ydt <- data[,ncol(data)-1]
D <- length(unique(data[,1]))
md <- rep(length(unique(data[,2])), D)
sigma2edt <- data[,ncol(data)]


### Calculating H3 and REML variance estimates
sigma.0 <- H3area(X, ydt, D, md, sigma2edt)

### Model with independent time effects
### Arguments: (X, ydt, D, md, sigma2edt, sigma.0, MAXITER = 500)
fit0 <- REMLarea.indep(X, ydt, D, md, sigma2edt, sigma.0=sigma.0)
sigmau.hat <- fit0[[1]]
if(sigmau.hat<0) {
    write.table(data.frame(sigmau.hat), file="VAR.NEGATIVE.indep.txt", append=TRUE)
    sigmau.hat <- 0
}
### Arguments: (X, ydt, D, md, sigma2edt, sigmau)
beta.u.hat <- BETA.U.area.indep(X, ydt, D, md, sigma2edt, sigmau.hat)
beta.hat0 <- beta.u.hat[1:ncol(X),]
Int0 <- Interval.indep(fit0, 0.90)
                beta.hat0-Int0[[2]]
                beta.hat0+Int0[[2]]
(pvalue0 <- pvalue(beta.hat0, fit0))
                pvalue0>0.1
udt.hat0 <- beta.u.hat[-(1:ncol(X)),]

### EBLUP of the population parameter
mudt.hat.0 <- as.vector(X%*%beta.hat0 + udt.hat0)
sqrt.mse.0 <- sqrt(mse.area.indep(X, D, md, sigma2edt, sigmau.hat, fit0[[2]]))
residuals.0 <- ydt-mudt.hat.0
Henderson3 <- sigma.0

###############################################################################
###############################################################################


### Reading data
data <- read.table(file = "dataExample.txt", header = T)

X <- as.matrix(data[,3:(ncol(data)-2)])
ydt <- data[,ncol(data)-1]
D <- length(unique(data[,1]))
md <- rep(length(unique(data[,2])), D)
sigma2edt <- data[,ncol(data)]


### Calculating H3 and REML variance estimates
sigma.0 <- H3area(X, ydt, D, md, sigma2edt)


### Model with time correlated effects
### Arguments: (X, ydt, D, md, sigma2edt, sigma.0, MAXITER = 500)
fit1 <- REMLarea.autocorr(X, ydt, D, md, sigma2edt, sigma.0=sigma.0)
sigmau.hat <- fit1[[1]][1]
rho.hat <- fit1[[1]][2]
if(sigmau.hat<0) {
    write.table(data.frame(sigmau.hat), file="VAR.NEGATIVE.autocorr.txt", append=TRUE, col.names=FALSE)
    sigmau.hat <- 0
}
if(rho.hat < -1 || rho.hat > 1 ) {
    write.table(data.frame(rho.hat), file="COEFFICIENT OF CORRELATION OUT OF RANGE.txt", append=TRUE, col.names=FALSE)
    if(rho.hat < -1) {
        rho.hat <- -0.8
    }
    else rho.hat <- 0.8
}

### Arguments: (X, ydt, D, md, sigma2edt, sigmau)
beta.u.hat <- BETA.U.area.autocorr(X, ydt, D, md, sigma2edt,
 sigmau.hat, rho.hat)
beta.hat1 <- beta.u.hat[1:ncol(X),]
Int1 <- Interval.autocorr(fit1, 0.90)
                beta.hat1-Int1[[3]]
                beta.hat1+Int1[[3]]
(pvalue1 <- pvalue(beta.hat1, fit1))
                pvalue1>0.1
udt.hat1 <- beta.u.hat[-(1:ncol(X)),]

### EBLUP of the population parameter
mudt.hat.1 <- as.vector(X%*%beta.hat1 + udt.hat1)
sqrt.mse.1 <- sqrt(mse.area.autocorr(X, D, md, sigma2edt, sigmau.hat,
 rho.hat, fit1[[2]]))
residuals.1 <- ydt-mudt.hat.1



### Create .txt files in the folder that contains for the resulting output
write.table(data.frame(data[,1:2], Direct=ydt, EBLUP.0=mudt.hat.0, EBLUP.1 = mudt.hat.1, sqrt.mse.direct=sqrt(sigma2edt), sqrt.mse.0, sqrt.mse.1),
file="EBLUP Example.txt",
row.names=FALSE, sep="\t")

write.table(data.frame(names(data)[3:(ncol(data)-2)], beta.hat0, Std.error.beta.hat0=Int0[[2]], beta.hat1, Std.error.beta.hat1=Int1[[3]]),
file="beta Example.txt",
row.names=FALSE, sep="\t")

write.table(data.frame(data[,1:2], udt.hat0, udt.hat1),
file="u Example.txt",
row.names=FALSE, sep="\t")

write.table(data.frame(data[,1:2], residuals.0, residuals.1),
file="res Example.txt",
row.names=FALSE, sep="\t")

write.table(data.frame(names(data)[3:(ncol(data)-2)], beta.hat0, pvalue0, beta.hat1, pvalue1),
file="pvalue Example.txt",
row.names=FALSE, sep="\t")

write.table(data.frame(Henderson3),
file="H3 Example.txt",
row.names=FALSE, sep="\t")


rm(list=ls(all=TRUE))



#
