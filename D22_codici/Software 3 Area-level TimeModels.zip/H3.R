###############################################################################
###
###              Area level model with independent time effects 
###                       and with time correlated effects
###                              SAMPLE project
###
### Author: Agust�n Perez Mart�n
### File name: H3.R
### Updated: November 25th, 2009
###
###############################################################################

H3area <- function(X, ydt, D, md, sigma2edt) {

    p <- ncol(X)
    a <- list(1:md[1])
    mdcum <- cumsum(md)
    M <- sum(md)

    for(d in 2:D)
        a[[d]] <- (mdcum[d-1]+1):mdcum[d]

    yd <- Xd <- list()
    for(d in 1:D) {
        yd[[d]] <- ydt[a[[d]]]
        Xd[[d]] <- X[a[[d]],]
    }

    Vd.inv <- VinvXd <- list()
    Q2.inv <- XV2X <- matrix(0, nrow=p, ncol=p)
    yVX <- 0
    for(d in 1:D) {

        ### Elements of the variance matrix
        vd <- sigma2edt[a[[d]]]

        ### Inverse matrix of the variance and submatrices
        Vd.inv[[d]] <- diag(1/vd)

        ### Product between V^-1_ed  and  X_d for all d submatrices
        VinvXd[[d]] <- Vd.inv[[d]]%*%Xd[[d]]

        ### Inverse of Q2. Next we calculate Q2
        Q2.inv <- Q2.inv + t(Xd[[d]])%*%VinvXd[[d]]

        ### Sum in d of the product with  y^t_d  and  V^-1_ed  and  X_d
        yVX <- yVX + yd[[d]]%*%VinvXd[[d]]
    }
    Q2 <- solve(Q2.inv)

    tr.XV2XQ2 <- 0
    for(d in 1:D)
        tr.XV2XQ2 <- tr.XV2XQ2 + sum(diag( t(VinvXd[[d]])%*%VinvXd[[d]]%*%Q2))

    tr.P2 <- sum(1/sigma2edt) - tr.XV2XQ2
    yP2y <- sum(ydt^2/sigma2edt) - yVX%*%Q2%*%t(yVX)

    sigma.u <- (yP2y - (M-p))/tr.P2

    return(as.vector(sigma.u))
}
