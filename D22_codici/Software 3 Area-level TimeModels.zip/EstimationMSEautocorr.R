###############################################################################
###
###              Area level model with time correlated effects
###                              SAMPLE project
###
### Author: Maria Dolores Esteban Lefler
### File name: EstimationMSEautocorr.R
### Updated: November 25th, 2009
###
###############################################################################

mse.area.autocorr <- function(X, D, md, sigma2edt, sigmau, rho, Fsig) {

    p <- ncol(X)
    a <- list(1:md[1])
    mdcum <- cumsum(md)
    for(d in 2:D)
        a[[d]] <- (mdcum[d-1]+1):mdcum[d]

    Xd <- Vd.inv <- Sed.inv <- Omegad  <- OmegadFirst <- VinvOmega <- OmegaVinvOmega <- VinvOmegaFirst  <-  
    OmegaVinvOmegaFirst <- OmegaFirstVinvOmegaFirst <- SinvXd <- OmegaVinvOmegadSinvXd <- g1.a  <- g2.a  <- q11  <- q12 <- q22 <- list()
    Q.inv <- matrix(0, nrow=p, ncol=p)

    for(d in 1:D) {

    ### Matrix Omegad and its derivative

       Omegad[[d]]<-matrix(0,nrow=md[d],ncol=md[d])
       Omegad[[d]][lower.tri(Omegad[[d]])]<-rho^sequence((md[d]-1):1)
       Omegad[[d]]<-Omegad[[d]]+t(Omegad[[d]])
       diag(Omegad[[d]])<-1
       Omegad[[d]] <- (1/(1-rho^2))*Omegad[[d]]

    ### Derivative

       OmegadFirst[[d]]<-matrix(0,nrow=md[d],ncol=md[d])
       OmegadFirst[[d]][lower.tri(OmegadFirst[[d]])] <-sequence((md[d]-1):1)*rho^(sequence((md[d]-1):1)-1)
       OmegadFirst[[d]]<-OmegadFirst[[d]]+t(OmegadFirst[[d]])
       OmegadFirst[[d]]<- (1/(1-rho^2))*OmegadFirst[[d]]
       OmegadFirst[[d]] <- OmegadFirst[[d]] + (2*rho/(1-rho^2))*Omegad[[d]]

       Xd[[d]] <- X[a[[d]],]

    ### Matrix Sigma_e
       Sed <- diag(sigma2edt[a[[d]]])

    ### Matrix of variance
       Vd <- (sigmau * Omegad[[d]] + Sed)

    ### Inverse matrix of the variance and d submatrices
       Vd.inv[[d]] <- solve(Vd)

    ### Inverse matrix of Sigma_ed in all d submatrices
       Sed.inv[[d]] <- solve(Sed)

    ### Product between V^-1_d and Omega
       VinvOmega[[d]] <-  Vd.inv[[d]]%*%  Omegad[[d]]


       VinvOmegaFirst[[d]] <-  Vd.inv[[d]]%*% OmegadFirst[[d]]

    ### Product between Omega, V^-1_d and Omega
       OmegaVinvOmega[[d]] <- t(VinvOmega[[d]])%*%Omegad[[d]]

    ### Product between Omega, V^-1_d and OmegadFirst
       OmegaVinvOmegaFirst[[d]] <- Omegad[[d]] %*% Vd.inv[[d]] %*% OmegadFirst[[d]]

    ### Product between OmegadFirst, V^-1_d and OmegadFirst
       OmegaFirstVinvOmegaFirst[[d]] <- OmegadFirst[[d]]%*%Vd.inv[[d]]%*%OmegadFirst[[d]]

    ### Product between Sigma^-1_ed and X_d for all d submatrices
       SinvXd[[d]] <- Sed.inv[[d]]%*%Xd[[d]]

    ### Product between Omegad, V^-1_d, Omegad, Sigma^-1_ed and X_d for d submatrices
       OmegaVinvOmegadSinvXd[[d]] <- OmegaVinvOmega[[d]]%*%SinvXd[[d]]

    ### First part of g1 (the second is its transpose)
       g1.a[[d]] <- sigmau * Omegad[[d]] - sigmau^2 *OmegaVinvOmega[[d]]

    ### First part of g2 (the second is its transpose)
       g2.a[[d]] <- Xd[[d]] - sigmau*Omegad[[d]]%*%SinvXd[[d]] + sigmau^2* OmegaVinvOmegadSinvXd[[d]]

       q11[[d]] <- OmegaVinvOmega[[d]] - 2*sigmau*OmegaVinvOmega[[d]]%*%VinvOmega[[d]] + sigmau^2*OmegaVinvOmega[[d]] %*% Vd.inv[[d]]%*%OmegaVinvOmega[[d]]
       
       q12[[d]] <- sigmau*OmegaVinvOmegaFirst[[d]] - sigmau^2*OmegaVinvOmegaFirst[[d]]%*%VinvOmega[[d]] - sigmau^2*OmegaVinvOmega[[d]]%*%VinvOmegaFirst[[d]]
                   + sigmau^3*OmegaVinvOmega[[d]]%*%VinvOmegaFirst[[d]]%*%VinvOmega[[d]]
       q22[[d]] <- sigmau^2*OmegaFirstVinvOmegaFirst[[d]] -2*sigmau^3*OmegaVinvOmegaFirst[[d]]%*% VinvOmegaFirst[[d]] 
                   + sigmau^4* OmegaVinvOmegaFirst[[d]]%*%Vd.inv[[d]]%*%t(OmegaVinvOmegaFirst[[d]])

    ### Inverse of Q. Next we calculate Q
    Q.inv <- Q.inv + t(Xd[[d]])%*%Vd.inv[[d]]%*%Xd[[d]]
    }

   Q <- solve(Q.inv)

   ### Calculation of g

   g1 <- g2 <- g3 <- list()
   for(d in 1:D){
       g1[[d]] <- diag(g1.a[[d]])
       g2[[d]] <- diag(g2.a[[d]]%*%Q%*%t(g2.a[[d]]))
       q11[[d]] <- diag(q11[[d]])
       q12[[d]] <- diag(q12[[d]])
       q22[[d]] <- diag(q22[[d]])
       }

   for(d in 1:D){
       g3[[d]] <- vector()
          for(t in 1:md[d]){
              g3[[d]][t] <- sum(diag(matrix(c(q11[[d]][t],rep(q12[[d]][t],2),q22[[d]][t]),nrow=2)%*%solve(Fsig)))
                }
    }

   g1 <- unlist(g1)
   g2 <- unlist(g2)
   g3 <- unlist(g3)

   return(g1+g2+2*g3)
}
