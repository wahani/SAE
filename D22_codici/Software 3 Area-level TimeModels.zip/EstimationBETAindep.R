###############################################################################
###
###              Area level model with independent time effects
###                              SAMPLE project
###
### Author: Agust�n Perez Mart�n
### File name: EstimationBETAindep.R
### Updated: November 25th, 2009
###
###############################################################################

BETA.U.area.indep <- function(X, ydt, D, md, sigma2edt, sigmau) {

    p <- ncol(X)
    a <- list(1:md[1])
    mdcum <- cumsum(md)
    for(d in 2:D)
        a[[d]] <- (mdcum[d-1]+1):mdcum[d]

    yd <- Xd <- Vd <- Vd.inv <- list()
    Q.inv <- matrix(0, nrow=p, ncol=p)
    XVy <- 0
    for(d in 1:D) {
        yd[[d]] <- ydt[a[[d]]]
        Xd[[d]] <- X[a[[d]],]

        ### Elements of the variance matrix
        vd <- (sigmau + sigma2edt)[a[[d]]]

        ### Inverse matrix of the variance and d submatrices
        Vd.inv[[d]] <- diag(1/vd)

        ### Inverse of Q. Next we calculate Q
        Q.inv <- Q.inv + t(Xd[[d]])%*%Vd.inv[[d]]%*%Xd[[d]]

        ### Product between X^t_d,  V^-1_d and y_d for all d submatrices
        XVy <- XVy + t(Xd[[d]])%*%Vd.inv[[d]]%*%yd[[d]]
    }
    Q <- solve(Q.inv)

    beta <- Q%*%XVy

    u <- list()
    for(d in 1:D)
        u[[d]] <- sigmau*Vd.inv[[d]]%*%(yd[[d]]-Xd[[d]]%*%beta)
    u <- as.matrix(unlist(u))

    return(rbind(beta,u))
}
