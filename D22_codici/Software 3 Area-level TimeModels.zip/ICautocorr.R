###############################################################################
###
###              Area level model with time correlated effects
###                              SAMPLE project
###
### Author: Maria Dolores Esteban Lefler
### File name: ICautocorr.R
### Updated: November 25th, 2009
###
###############################################################################

Interval.autocorr <- function(fit, conf=0.95) {
    alfa <- 1-conf
    k <- 1-alfa/2
    z <- qnorm(k)

    Finv <- solve(fit[[2]])

    sigma.std.err <- z*sqrt(Finv[1,1])
    rho.std.err <- z*sqrt(Finv[2,2])
    beta.std.err <- z*sqrt(as.vector(diag(fit[[3]])))

    return( list(sigma.std.err, rho.std.err, beta.std.err) )
}
