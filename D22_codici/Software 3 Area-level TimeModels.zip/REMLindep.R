###############################################################################
###
###              Area level model with independent time effects
###                              SAMPLE project
###
### Author: Agust�n Perez Mart�n
### File name: REMLindep.R
### Updated: November 25th, 2009
###
###############################################################################

REMLarea.indep <- function(X, ydt, D, md, sigma2edt, sigma.0, MAXITER = 500){

    sigma.f <- sigma.0
    p <- ncol(X)
    a <- list(1:md[1])
    mdcum <- cumsum(md)
    for(d in 2:D)
        a[[d]] <- (mdcum[d-1]+1):mdcum[d]


    yd <- Xd <- list()
    for(d in 1:D) {
        yd[[d]] <- ydt[a[[d]]]
        Xd[[d]] <- X[a[[d]],]
    }

    for(ITER in 1:MAXITER){
        Vd.inv <- Vinvyd <- VinvXd <- list()
        Q.inv <- XV2X <- XV3X <- matrix(0, nrow=p, ncol=p)
        tr.V.inv <- tr.V2.inv <- yV2y <- yVX <- XV2y <- 0
        for(d in 1:D) {

            ### Elements of the variance matrix
            vd <- (sigma.f + sigma2edt)[a[[d]]]

            ### Inverse matrix of the variance and submatrices
            Vd.inv[[d]] <- diag(1/vd)

            ### Product between V^-1_ed  and  y_d for all d submatrices
            Vinvyd[[d]] <- Vd.inv[[d]]%*%yd[[d]]

            ### Product between V^-1_ed  and  X_d for all d submatrices
            VinvXd[[d]] <- Vd.inv[[d]]%*%Xd[[d]]

            ### Inverse of Q. Next we calculate Q
            Q.inv <- Q.inv + t(Xd[[d]])%*%VinvXd[[d]]

            ### Sum traces of V^-1_d
            tr.V.inv <- tr.V.inv + sum(1/vd)

            ### Sum traces of V^-2_d
            tr.V2.inv <- tr.V2.inv + sum(1/vd^2)

            ### Sum on d of the product between  X^t_d, V^-2_d and X_d
            XV2X <- XV2X + t(VinvXd[[d]])%*%VinvXd[[d]]

            ### Sum on d of the product between  X^t_d, V^-3_d and X_d
            XV3X <- XV3X + t(VinvXd[[d]])%*%Vd.inv[[d]]%*%VinvXd[[d]]

            ### Sum on d of the product between  y^t_d, V^-2_d and y_d
            yV2y <- yV2y + t(Vinvyd[[d]])%*%Vinvyd[[d]]

            ### Sum on d of the product between  y^t_d, V^-1_d and X_d
            yVX <- yVX + yd[[d]]%*%VinvXd[[d]]

            ### Sum on d of the product between  X^t_d, V^-2_d and y_d
            XV2y <- XV2y + t(VinvXd[[d]])%*%Vinvyd[[d]]
        }
        Q <- solve(Q.inv)

        tr.XV2XQ <- 0
        for(d in 1:D)
            tr.XV2XQ <- tr.XV2XQ + sum(diag( t(VinvXd[[d]])%*%VinvXd[[d]]%*%Q))

        tr.P <- tr.V.inv - tr.XV2XQ
        tr.P2 <- tr.V2.inv - 2*sum(diag(XV3X%*%Q)) + sum(diag(XV2X%*%Q%*%XV2X%*%Q))
        yP2y <- yV2y - 2*yVX%*%Q%*%XV2y + yVX%*%Q%*%XV2X%*%Q%*%t(yVX)

        ### Scores and Fisher information matrix
        Ssig <- -0.5*tr.P + 0.5*yP2y
        Fsig <- 0.5*tr.P2

        ### Fisher-Scoring Algorithm
        dif <- Ssig/Fsig
        sigma.f <- sigma.f + dif

        ### Stopping criterion
        if(abs(dif)<0.000001)
            break
    }

    return(list(as.vector(sigma.f), Fsig, Q))
}


###############################################################################
###
###              Area level model with time correlated effects
###                              SAMPLE project
###
### Author: Maria Dolore Esteban Lefler
### File name: REML.R
### Updated: November 5th, 2009
###
###############################################################################


REMLarea.autocorr <- function(X, ydt, D, md, sigma2edt, sigma.0=100, MAXITER=100){

    rho.f <- 0
    sigma.f <- sigma.0
    theta.f  <- c(sigma.f,rho.f)
    p <- ncol(X)
    a <- list(1:md[1])
    mdcum <- cumsum(md)
    for(d in 2:D)
        a[[d]] <- (mdcum[d-1]+1):mdcum[d]

    yd <- Xd <- list()
    for(d in 1:D) {
        yd[[d]] <- ydt[a[[d]]]
        Xd[[d]] <- X[a[[d]],]
    }


    for(ITER in 1:MAXITER){
        Vd.inv <- Vad  <- Vbd <- VinvVad <- VinvVbd  <- Vinvyd <- VinvXd <- XtVinvVadVinvX  <- XtVinvVbdVinvX <- VinvVadVinvVad <-  VinvVadVinvVad <-
          VinvVadVinvVad <- XtVinvVadVinvVadVinvX <- VinvVbdVinvVbd <- VinvVadVinvVbd <-  XtVinvVbdVinvVbdVinvX <- XtVinvVadVinvVbdVinvX <- list()
        
        Q.inv <- matrix(0, nrow=p, ncol=p)
        
        tr.VinvVad  <- tr.VinvVbd   <- tr.VinvVadVinvVad  <- tr.VinvVbdVinvVbd <- tr.VinvVadVinvVbd  <- ytVinvX <- ytVinvVadVinvy  <- SumXtVinvVadVinvX <- 
        ytVinvVadVinvX  <- ytVinvVbdVinvy  <- ytVinvVbdVinvX <- SumXtVinvVbdVinvX   <- 0



    ### Matrix Omegad and its derivative

    for(d in 1:D) {
        Omegad<-matrix(0,nrow=md[d],ncol=md[d])
        Omegad[lower.tri(Omegad)]<-rho.f^sequence((md[d]-1):1)
        Omegad<-Omegad+t(Omegad)
        diag(Omegad)<-1
        Omegad <- (1/(1-rho.f^2))*Omegad
        Vad[[d]] <- Omegad

    ### Derivative

        OmegadFirst<-matrix(0,nrow=md[d],ncol=md[d])
        OmegadFirst[lower.tri(OmegadFirst)]<-sequence((md[d]-1):1)*
                                         rho.f^(sequence((md[d]-1):1)-1)
        OmegadFirst<-OmegadFirst+t(OmegadFirst)
        OmegadFirst<- (1/(1-rho.f^2))*OmegadFirst
        OmegadFirst <- OmegadFirst + (2*rho.f/(1-rho.f^2))*Omegad
        Vbd[[d]] <- sigma.f*OmegadFirst

    ### Matrix Calculation for Scores and F

    ### Elements of the variance matrix
        Vd <- (sigma.f * Omegad + diag(sigma2edt[a[[d]]]))

    ### Inverse matrix of the variance and submatrices
        Vd.inv[[d]] <- solve(Vd)

   ### Product between V^-1_ed  and  y_d for all d submatrices
        Vinvyd[[d]] <- Vd.inv[[d]]%*%yd[[d]]

   ### Product between V^-1_ed  and  X_d for all d submatrices
        VinvXd[[d]] <- Vd.inv[[d]]%*%Xd[[d]]

   ### Inverse of Q. Next we calculate Q
       Q.inv <- Q.inv + t(Xd[[d]])%*%VinvXd[[d]]

   ### Sa
       VinvVad[[d]] <- Vd.inv[[d]]%*%Vad[[d]]
       tr.VinvVad <-  tr.VinvVad + sum(diag(VinvVad[[d]]))

       XtVinvVadVinvX[[d]]<- t(VinvXd[[d]])%*%Vad[[d]]%*%VinvXd[[d]]

       ytVinvX <- ytVinvX + t(yd[[d]])%*%VinvXd[[d]]
       ytVinvVadVinvy <- ytVinvVadVinvy + t(Vinvyd[[d]])%*%Vad[[d]]%*%Vinvyd[[d]]
       ytVinvVadVinvX <-  ytVinvVadVinvX + t(Vinvyd[[d]])%*%Vad[[d]]%*%VinvXd[[d]]
       SumXtVinvVadVinvX <- SumXtVinvVadVinvX + XtVinvVadVinvX[[d]]

   ### Sb
       VinvVbd[[d]] <- Vd.inv[[d]]%*%Vbd[[d]]
       tr.VinvVbd <-  tr.VinvVbd + sum(diag(VinvVbd[[d]]))

       XtVinvVbdVinvX[[d]] <- t(VinvXd[[d]])%*%Vbd[[d]]%*%VinvXd[[d]]

       ytVinvVbdVinvy <- ytVinvVbdVinvy + t(Vinvyd[[d]])%*%Vbd[[d]]%*%Vinvyd[[d]]
       ytVinvVbdVinvX <-  ytVinvVbdVinvX + t(Vinvyd[[d]])%*%Vbd[[d]]%*%VinvXd[[d]]
       SumXtVinvVbdVinvX <- SumXtVinvVbdVinvX + XtVinvVbdVinvX[[d]]

   ### Faa
       VinvVadVinvVad[[d]] <- Vd.inv[[d]]%*%Vad[[d]]%*%Vd.inv[[d]]%*%Vad[[d]]
       tr.VinvVadVinvVad <- tr.VinvVadVinvVad + sum(diag(VinvVadVinvVad[[d]]))

       XtVinvVadVinvVadVinvX[[d]] <- t(VinvXd[[d]])%*%Vad[[d]]%*%Vd.inv[[d]]%*%Vad[[d]]%*%VinvXd[[d]]

   ### Fbb
       VinvVbdVinvVbd[[d]] <- Vd.inv[[d]]%*%Vbd[[d]]%*%Vd.inv[[d]]%*%Vbd[[d]]
       tr.VinvVbdVinvVbd <- tr.VinvVbdVinvVbd + sum(diag(VinvVbdVinvVbd[[d]]))

       XtVinvVbdVinvVbdVinvX[[d]] <- t(VinvXd[[d]])%*%Vbd[[d]]%*%Vd.inv[[d]]%*%Vbd[[d]]%*%VinvXd[[d]]

   ### Fab
       VinvVadVinvVbd[[d]]  <- Vd.inv[[d]]%*%Vad[[d]]%*%Vd.inv[[d]]%*%Vbd[[d]]
       tr.VinvVadVinvVbd <- tr.VinvVadVinvVbd + sum(diag(VinvVadVinvVbd[[d]]))

       XtVinvVadVinvVbdVinvX[[d]] <- t(VinvXd[[d]])%*%Vad[[d]]%*%Vd.inv[[d]]%*%Vbd[[d]]%*%VinvXd[[d]]
        }

   Q <- solve(Q.inv)


   tr.XtVinvVadVinvXQ <- tr.XtVinvVbdVinvXQ  <- tr.XtVinvVadVinvVadVinvXQ <- tr.XtVinvVbdVinvVbdVinvXQ <- tr.XtVinvVadVinvVbdVinvXQ <- tr.XtVinvVbdVinvVbdVinvXQ <- XtVinvVadVinvXQ <- XtVinvVbdVinvXQ <- 0


   for(d in 1:D){
       tr.XtVinvVadVinvXQ <- tr.XtVinvVadVinvXQ + sum(diag(XtVinvVadVinvX[[d]]%*%Q))
       tr.XtVinvVbdVinvXQ <- tr.XtVinvVbdVinvXQ + sum(diag(XtVinvVbdVinvX[[d]]%*%Q))
       tr.XtVinvVadVinvVadVinvXQ <- tr.XtVinvVadVinvVadVinvXQ + sum(diag(XtVinvVadVinvVadVinvX[[d]]%*%Q))
       XtVinvVadVinvXQ  <- XtVinvVadVinvXQ + XtVinvVadVinvX[[d]]%*%Q
       tr.XtVinvVbdVinvVbdVinvXQ <- tr.XtVinvVbdVinvVbdVinvXQ + sum(diag(XtVinvVbdVinvVbdVinvX[[d]]%*%Q))
       XtVinvVbdVinvXQ  <- XtVinvVbdVinvXQ + XtVinvVbdVinvX[[d]]%*%Q
       tr.XtVinvVadVinvVbdVinvXQ <- tr.XtVinvVadVinvVbdVinvXQ + sum(diag(XtVinvVadVinvVbdVinvX[[d]]%*%Q))
        }

   tr.XtVinvVadVinvXQXtVinvVadVinvXQ <- sum(diag(XtVinvVadVinvXQ%*%XtVinvVadVinvXQ))
   tr.XtVinvVbdVinvXQXtVinvVbdVinvXQ <- sum(diag(XtVinvVbdVinvXQ%*%XtVinvVbdVinvXQ))
   tr.XtVinvVadVinvXQXtVinvVbdVinvXQ <- sum(diag(XtVinvVadVinvXQ%*%XtVinvVbdVinvXQ))

   tr.PVa <- tr.VinvVad - tr.XtVinvVadVinvXQ
   tr.PVb <- tr.VinvVbd - tr.XtVinvVbdVinvXQ
   tr.PVaPVa  <- tr.VinvVadVinvVad - 2*tr.XtVinvVadVinvVadVinvXQ + tr.XtVinvVadVinvXQXtVinvVadVinvXQ
   tr.PVbPVb  <- tr.VinvVbdVinvVbd - 2*tr.XtVinvVbdVinvVbdVinvXQ + tr.XtVinvVbdVinvXQXtVinvVbdVinvXQ
   tr.PVaPVb  <- tr.VinvVadVinvVbd - 2*tr.XtVinvVadVinvVbdVinvXQ + tr.XtVinvVadVinvXQXtVinvVbdVinvXQ

   ytPVaPy  <- ytVinvVadVinvy - ytVinvVadVinvX%*%Q%*%t(ytVinvX) - ytVinvX%*%Q%*%t(ytVinvVadVinvX) + ytVinvX%*%Q%*%SumXtVinvVadVinvX%*%Q%*%t(ytVinvX)

   ytPVbPy  <- ytVinvVbdVinvy - ytVinvVbdVinvX%*%Q%*%t(ytVinvX) - ytVinvX%*%Q%*%t(ytVinvVbdVinvX) + ytVinvX%*%Q%*%SumXtVinvVbdVinvX%*%Q%*%t(ytVinvX)


   ### Scores and Fisher information matrix

   Sa <- -0.5*tr.PVa + 0.5*ytPVaPy
   Sb <- -0.5*tr.PVb + 0.5*ytPVbPy
   Faa  <- 0.5*tr.PVaPVa
   Fbb  <- 0.5*tr.PVbPVb
   Fab  <- 0.5*tr.PVaPVb

   Ssig <- c(Sa,Sb)
   Fsig <- matrix(c(Faa,Fab,Fab,Fbb),ncol=2)

   ### Fisher-Scoring Algorithm

   Fsig.inv <- solve(Fsig)
   dif <- Fsig.inv%*%Ssig

   theta.f <- theta.f + dif
  
   ###print(rho.f)
   rho.f <- theta.f[2,1]
  
   ###print(sigma.f)
   sigma.f <- theta.f[1,1]


   ### output3 <- data.frame(ITER, Sa, Sb, Faa, Fbb, Fab)
   ### output3 <- as.data.frame(t(output3))
   ### write.table(output3, file="Output3.txt", sep="\t")

   ### Stopping criterion
   if(abs(dif[1,1])<0.000001 && abs(dif[2,1])<0.000001)
      break
    }

   return(list(as.vector(theta.f), Fsig, Q))
}
