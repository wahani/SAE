library(testthat)
library(SAE)

test_package("SAE")